--
-- PostgreSQL database dump
--

\restrict FuzmbaSDPAFo4IbjBRd58wVY9yu5K9NIxAbVzNXmprwPN8xXLhjbIcSPJ6UBvE9

-- Dumped from database version 14.22 (Ubuntu 14.22-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 14.22 (Ubuntu 14.22-0ubuntu0.22.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: geo_campaign_status; Type: TYPE; Schema: public; Owner: gigzito
--

CREATE TYPE public.geo_campaign_status AS ENUM (
    'ACTIVE',
    'PAUSED',
    'ENDED'
);


ALTER TYPE public.geo_campaign_status OWNER TO gigzito;

--
-- Name: gig_jack_status; Type: TYPE; Schema: public; Owner: gigzito
--

CREATE TYPE public.gig_jack_status AS ENUM (
    'PENDING_REVIEW',
    'APPROVED',
    'REJECTED',
    'NEEDS_IMPROVEMENT',
    'DENIED'
);


ALTER TYPE public.gig_jack_status OWNER TO gigzito;

--
-- Name: listing_status; Type: TYPE; Schema: public; Owner: gigzito
--

CREATE TYPE public.listing_status AS ENUM (
    'PENDING',
    'ACTIVE',
    'PAUSED',
    'REMOVED',
    'TRIAGED'
);


ALTER TYPE public.listing_status OWNER TO gigzito;

--
-- Name: role; Type: TYPE; Schema: public; Owner: gigzito
--

CREATE TYPE public.role AS ENUM (
    'VISITOR',
    'PROVIDER',
    'MEMBER',
    'MARKETER',
    'INFLUENCER',
    'CORPORATE',
    'SUPERUSER',
    'ADMIN',
    'SUPER_ADMIN',
    'COORDINATOR'
);


ALTER TYPE public.role OWNER TO gigzito;

--
-- Name: subscription_tier; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.subscription_tier AS ENUM (
    'GZLurker',
    'GZMarketer',
    'GZMarketerPro',
    'GZBusiness',
    'GZEnterprise'
);


ALTER TYPE public.subscription_tier OWNER TO postgres;

--
-- Name: vertical; Type: TYPE; Schema: public; Owner: gigzito
--

CREATE TYPE public.vertical AS ENUM (
    'MARKETING',
    'COACHING',
    'COURSES',
    'MUSIC',
    'CRYPTO',
    'INFLUENCER',
    'PRODUCTS',
    'FLASH_SALE',
    'FLASH_COUPON',
    'MUSIC_GIGS',
    'EVENTS',
    'CORPORATE_DEALS',
    'ARTISTS',
    'BUSINESS',
    'FOR_SALE',
    'LAIH',
    'RANDOMNESS',
    'HEALTH',
    'SCIENCE',
    'RANTS',
    'GZ_MUSIC'
);


ALTER TYPE public.vertical OWNER TO gigzito;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ad_bookings; Type: TABLE; Schema: public; Owner: gigzito
--

CREATE TABLE public.ad_bookings (
    id integer NOT NULL,
    sponsor_ad_id integer,
    booking_date text NOT NULL,
    slot_number integer NOT NULL,
    advertiser_name text NOT NULL,
    advertiser_email text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    amount_cents integer DEFAULT 0 NOT NULL,
    notes text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.ad_bookings OWNER TO gigzito;

--
-- Name: ad_bookings_id_seq; Type: SEQUENCE; Schema: public; Owner: gigzito
--

CREATE SEQUENCE public.ad_bookings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ad_bookings_id_seq OWNER TO gigzito;

--
-- Name: ad_bookings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gigzito
--

ALTER SEQUENCE public.ad_bookings_id_seq OWNED BY public.ad_bookings.id;


--
-- Name: ad_inquiries; Type: TABLE; Schema: public; Owner: gigzito
--

CREATE TABLE public.ad_inquiries (
    id integer NOT NULL,
    ad_id integer NOT NULL,
    advertiser_username text,
    viewer_name text NOT NULL,
    viewer_email text,
    viewer_message text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    viewer_username text,
    viewer_city text,
    viewer_state text,
    viewer_country text,
    is_read boolean DEFAULT false NOT NULL
);


ALTER TABLE public.ad_inquiries OWNER TO gigzito;

--
-- Name: ad_inquiries_id_seq; Type: SEQUENCE; Schema: public; Owner: gigzito
--

CREATE SEQUENCE public.ad_inquiries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ad_inquiries_id_seq OWNER TO gigzito;

--
-- Name: ad_inquiries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gigzito
--

ALTER SEQUENCE public.ad_inquiries_id_seq OWNED BY public.ad_inquiries.id;


--
-- Name: all_eyes_slots; Type: TABLE; Schema: public; Owner: gigzito
--

CREATE TABLE public.all_eyes_slots (
    id integer NOT NULL,
    provider_id integer NOT NULL,
    video_listing_id integer,
    custom_title text,
    duration_minutes integer NOT NULL,
    start_at timestamp without time zone NOT NULL,
    end_at timestamp without time zone NOT NULL,
    status text DEFAULT 'scheduled'::text NOT NULL,
    price_cents integer DEFAULT 0 NOT NULL,
    created_by integer,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.all_eyes_slots OWNER TO gigzito;

--
-- Name: all_eyes_slots_id_seq; Type: SEQUENCE; Schema: public; Owner: gigzito
--

CREATE SEQUENCE public.all_eyes_slots_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.all_eyes_slots_id_seq OWNER TO gigzito;

--
-- Name: all_eyes_slots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gigzito
--

ALTER SEQUENCE public.all_eyes_slots_id_seq OWNED BY public.all_eyes_slots.id;


--
-- Name: audience_broadcasts; Type: TABLE; Schema: public; Owner: gigzito
--

CREATE TABLE public.audience_broadcasts (
    id integer NOT NULL,
    provider_user_id integer NOT NULL,
    subject text NOT NULL,
    body text NOT NULL,
    recipient_count integer DEFAULT 0 NOT NULL,
    sent_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.audience_broadcasts OWNER TO gigzito;

--
-- Name: audience_broadcasts_id_seq; Type: SEQUENCE; Schema: public; Owner: gigzito
--

CREATE SEQUENCE public.audience_broadcasts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.audience_broadcasts_id_seq OWNER TO gigzito;

--
-- Name: audience_broadcasts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gigzito
--

ALTER SEQUENCE public.audience_broadcasts_id_seq OWNED BY public.audience_broadcasts.id;


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: gigzito
--

CREATE TABLE public.audit_logs (
    id integer NOT NULL,
    actor_user_id integer,
    action_type text NOT NULL,
    target_type text NOT NULL,
    target_id integer,
    old_value text,
    new_value text,
    used_override boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.audit_logs OWNER TO gigzito;

--
-- Name: audit_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: gigzito
--

CREATE SEQUENCE public.audit_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.audit_logs_id_seq OWNER TO gigzito;

--
-- Name: audit_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gigzito
--

ALTER SEQUENCE public.audit_logs_id_seq OWNED BY public.audit_logs.id;


--
-- Name: card_messages; Type: TABLE; Schema: public; Owner: gigzito
--

CREATE TABLE public.card_messages (
    id integer NOT NULL,
    from_user_id integer NOT NULL,
    to_user_id integer NOT NULL,
    gigness_card_id integer NOT NULL,
    message_text text,
    emoji_reaction text,
    is_clean boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    is_read boolean DEFAULT false NOT NULL
);


ALTER TABLE public.card_messages OWNER TO gigzito;

--
-- Name: card_messages_id_seq; Type: SEQUENCE; Schema: public; Owner: gigzito
--

CREATE SEQUENCE public.card_messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.card_messages_id_seq OWNER TO gigzito;

--
-- Name: card_messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gigzito
--

ALTER SEQUENCE public.card_messages_id_seq OWNED BY public.card_messages.id;


--
-- Name: geezee_follows; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.geezee_follows (
    id integer NOT NULL,
    follower_id integer NOT NULL,
    following_user_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.geezee_follows OWNER TO postgres;

--
-- Name: geezee_follows_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.geezee_follows_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.geezee_follows_id_seq OWNER TO postgres;

--
-- Name: geezee_follows_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.geezee_follows_id_seq OWNED BY public.geezee_follows.id;


--
-- Name: geo_target_campaigns; Type: TABLE; Schema: public; Owner: gigzito
--

CREATE TABLE public.geo_target_campaigns (
    id integer NOT NULL,
    provider_user_id integer NOT NULL,
    title text NOT NULL,
    offer text NOT NULL,
    radius_miles integer DEFAULT 10 NOT NULL,
    city text,
    state text,
    country text DEFAULT 'US'::text NOT NULL,
    lat text,
    lng text,
    image_url text,
    status public.geo_campaign_status DEFAULT 'ACTIVE'::public.geo_campaign_status NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.geo_target_campaigns OWNER TO gigzito;

--
-- Name: geo_target_campaigns_id_seq; Type: SEQUENCE; Schema: public; Owner: gigzito
--

CREATE SEQUENCE public.geo_target_campaigns_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.geo_target_campaigns_id_seq OWNER TO gigzito;

--
-- Name: geo_target_campaigns_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gigzito
--

ALTER SEQUENCE public.geo_target_campaigns_id_seq OWNED BY public.geo_target_campaigns.id;


--
-- Name: gig_jacks; Type: TABLE; Schema: public; Owner: gigzito
--

CREATE TABLE public.gig_jacks (
    id integer NOT NULL,
    provider_id integer NOT NULL,
    company_url text NOT NULL,
    artwork_url text NOT NULL,
    offer_title text NOT NULL,
    description text NOT NULL,
    cta_link text NOT NULL,
    countdown_minutes integer NOT NULL,
    coupon_code text,
    quantity_limit integer,
    tagline text,
    category text,
    scheduled_at timestamp without time zone,
    booked_date text,
    booked_hour integer,
    flash_duration_seconds integer DEFAULT 7,
    offer_duration_minutes integer DEFAULT 10,
    status public.gig_jack_status DEFAULT 'PENDING_REVIEW'::public.gig_jack_status NOT NULL,
    display_state text DEFAULT 'hidden'::text NOT NULL,
    siren_enabled boolean DEFAULT true NOT NULL,
    review_note text,
    bot_warning boolean DEFAULT false NOT NULL,
    bot_warning_message text,
    approved_at timestamp without time zone,
    approved_by integer,
    denied_at timestamp without time zone,
    denied_by integer,
    removed_at timestamp without time zone,
    removed_by integer,
    flash_started_at timestamp without time zone,
    flash_ended_at timestamp without time zone,
    offer_started_at timestamp without time zone,
    offer_ends_at timestamp without time zone,
    completed_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.gig_jacks OWNER TO gigzito;

--
-- Name: gig_jacks_id_seq; Type: SEQUENCE; Schema: public; Owner: gigzito
--

CREATE SEQUENCE public.gig_jacks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gig_jacks_id_seq OWNER TO gigzito;

--
-- Name: gig_jacks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gigzito
--

ALTER SEQUENCE public.gig_jacks_id_seq OWNED BY public.gig_jacks.id;


--
-- Name: gigness_card_comments; Type: TABLE; Schema: public; Owner: gigzito
--

CREATE TABLE public.gigness_card_comments (
    id integer NOT NULL,
    card_id integer NOT NULL,
    author_user_id integer,
    author_name text DEFAULT 'Anonymous'::text NOT NULL,
    comment_text text NOT NULL,
    is_clean boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.gigness_card_comments OWNER TO gigzito;

--
-- Name: gigness_card_comments_id_seq; Type: SEQUENCE; Schema: public; Owner: gigzito
--

CREATE SEQUENCE public.gigness_card_comments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gigness_card_comments_id_seq OWNER TO gigzito;

--
-- Name: gigness_card_comments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gigzito
--

ALTER SEQUENCE public.gigness_card_comments_id_seq OWNED BY public.gigness_card_comments.id;


--
-- Name: gigness_cards; Type: TABLE; Schema: public; Owner: gigzito
--

CREATE TABLE public.gigness_cards (
    id integer NOT NULL,
    user_id integer NOT NULL,
    qr_uuid text DEFAULT (gen_random_uuid())::text NOT NULL,
    slogan text DEFAULT ''::text NOT NULL,
    profile_pic text,
    gallery text[] DEFAULT '{}'::text[] NOT NULL,
    is_public boolean DEFAULT true NOT NULL,
    age_bracket text,
    gender text,
    intent text,
    engagement_count integer DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    location_services_enabled boolean DEFAULT false NOT NULL,
    allow_messaging boolean DEFAULT true NOT NULL,
    show_social_links boolean DEFAULT false NOT NULL
);


ALTER TABLE public.gigness_cards OWNER TO gigzito;

--
-- Name: gigness_cards_id_seq; Type: SEQUENCE; Schema: public; Owner: gigzito
--

CREATE SEQUENCE public.gigness_cards_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gigness_cards_id_seq OWNER TO gigzito;

--
-- Name: gigness_cards_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gigzito
--

ALTER SEQUENCE public.gigness_cards_id_seq OWNED BY public.gigness_cards.id;


--
-- Name: group_email_invites; Type: TABLE; Schema: public; Owner: gigzito
--

CREATE TABLE public.group_email_invites (
    id integer NOT NULL,
    group_id integer NOT NULL,
    email text NOT NULL,
    token text NOT NULL,
    invited_by integer NOT NULL,
    group_name text NOT NULL,
    inviter_name text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    expires_at timestamp without time zone DEFAULT (now() + '7 days'::interval) NOT NULL,
    claimed_by integer,
    claimed_at timestamp without time zone
);


ALTER TABLE public.group_email_invites OWNER TO gigzito;

--
-- Name: group_email_invites_id_seq; Type: SEQUENCE; Schema: public; Owner: gigzito
--

CREATE SEQUENCE public.group_email_invites_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.group_email_invites_id_seq OWNER TO gigzito;

--
-- Name: group_email_invites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gigzito
--

ALTER SEQUENCE public.group_email_invites_id_seq OWNED BY public.group_email_invites.id;


--
-- Name: group_endeavors; Type: TABLE; Schema: public; Owner: gigzito
--

CREATE TABLE public.group_endeavors (
    id integer NOT NULL,
    group_id integer NOT NULL,
    title text NOT NULL,
    description text,
    goal_progress integer DEFAULT 0 NOT NULL,
    created_by integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.group_endeavors OWNER TO gigzito;

--
-- Name: group_endeavors_id_seq; Type: SEQUENCE; Schema: public; Owner: gigzito
--

CREATE SEQUENCE public.group_endeavors_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.group_endeavors_id_seq OWNER TO gigzito;

--
-- Name: group_endeavors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gigzito
--

ALTER SEQUENCE public.group_endeavors_id_seq OWNED BY public.group_endeavors.id;


--
-- Name: group_events; Type: TABLE; Schema: public; Owner: gigzito
--

CREATE TABLE public.group_events (
    id integer NOT NULL,
    group_id integer NOT NULL,
    title text NOT NULL,
    description text,
    start_at timestamp with time zone NOT NULL,
    end_at timestamp with time zone,
    all_day boolean DEFAULT false NOT NULL,
    created_by integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.group_events OWNER TO gigzito;

--
-- Name: group_events_id_seq; Type: SEQUENCE; Schema: public; Owner: gigzito
--

CREATE SEQUENCE public.group_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.group_events_id_seq OWNER TO gigzito;

--
-- Name: group_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gigzito
--

ALTER SEQUENCE public.group_events_id_seq OWNED BY public.group_events.id;


--
-- Name: group_kanban_cards; Type: TABLE; Schema: public; Owner: gigzito
--

CREATE TABLE public.group_kanban_cards (
    id integer NOT NULL,
    group_id integer NOT NULL,
    title text NOT NULL,
    description text,
    status text DEFAULT 'todo'::text NOT NULL,
    "position" integer DEFAULT 0 NOT NULL,
    created_by integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.group_kanban_cards OWNER TO gigzito;

--
-- Name: group_kanban_cards_id_seq; Type: SEQUENCE; Schema: public; Owner: gigzito
--

CREATE SEQUENCE public.group_kanban_cards_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.group_kanban_cards_id_seq OWNER TO gigzito;

--
-- Name: group_kanban_cards_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gigzito
--

ALTER SEQUENCE public.group_kanban_cards_id_seq OWNED BY public.group_kanban_cards.id;


--
-- Name: group_members; Type: TABLE; Schema: public; Owner: gigzito
--

CREATE TABLE public.group_members (
    id integer NOT NULL,
    group_id integer NOT NULL,
    user_id integer NOT NULL,
    role text DEFAULT 'member'::text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    invited_by integer,
    joined_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.group_members OWNER TO gigzito;

--
-- Name: group_members_id_seq; Type: SEQUENCE; Schema: public; Owner: gigzito
--

CREATE SEQUENCE public.group_members_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.group_members_id_seq OWNER TO gigzito;

--
-- Name: group_members_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gigzito
--

ALTER SEQUENCE public.group_members_id_seq OWNED BY public.group_members.id;


--
-- Name: group_wall_comments; Type: TABLE; Schema: public; Owner: gigzito
--

CREATE TABLE public.group_wall_comments (
    id integer NOT NULL,
    post_id integer NOT NULL,
    group_id integer NOT NULL,
    user_id integer NOT NULL,
    content text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.group_wall_comments OWNER TO gigzito;

--
-- Name: group_wall_comments_id_seq; Type: SEQUENCE; Schema: public; Owner: gigzito
--

CREATE SEQUENCE public.group_wall_comments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.group_wall_comments_id_seq OWNER TO gigzito;

--
-- Name: group_wall_comments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gigzito
--

ALTER SEQUENCE public.group_wall_comments_id_seq OWNED BY public.group_wall_comments.id;


--
-- Name: group_wall_posts; Type: TABLE; Schema: public; Owner: gigzito
--

CREATE TABLE public.group_wall_posts (
    id integer NOT NULL,
    group_id integer NOT NULL,
    user_id integer NOT NULL,
    content text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.group_wall_posts OWNER TO gigzito;

--
-- Name: group_wall_posts_id_seq; Type: SEQUENCE; Schema: public; Owner: gigzito
--

CREATE SEQUENCE public.group_wall_posts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.group_wall_posts_id_seq OWNER TO gigzito;

--
-- Name: group_wall_posts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gigzito
--

ALTER SEQUENCE public.group_wall_posts_id_seq OWNED BY public.group_wall_posts.id;


--
-- Name: group_wallet_contributions; Type: TABLE; Schema: public; Owner: gigzito
--

CREATE TABLE public.group_wallet_contributions (
    id integer NOT NULL,
    wallet_id integer NOT NULL,
    group_id integer NOT NULL,
    user_id integer NOT NULL,
    amount real NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    tx_hash text,
    note text,
    display_name text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.group_wallet_contributions OWNER TO gigzito;

--
-- Name: group_wallet_contributions_id_seq; Type: SEQUENCE; Schema: public; Owner: gigzito
--

CREATE SEQUENCE public.group_wallet_contributions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.group_wallet_contributions_id_seq OWNER TO gigzito;

--
-- Name: group_wallet_contributions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gigzito
--

ALTER SEQUENCE public.group_wallet_contributions_id_seq OWNED BY public.group_wallet_contributions.id;


--
-- Name: group_wallets; Type: TABLE; Schema: public; Owner: gigzito
--

CREATE TABLE public.group_wallets (
    id integer NOT NULL,
    group_id integer NOT NULL,
    label text NOT NULL,
    network text NOT NULL,
    address text NOT NULL,
    link text,
    created_by integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.group_wallets OWNER TO gigzito;

--
-- Name: group_wallets_id_seq; Type: SEQUENCE; Schema: public; Owner: gigzito
--

CREATE SEQUENCE public.group_wallets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.group_wallets_id_seq OWNER TO gigzito;

--
-- Name: group_wallets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gigzito
--

ALTER SEQUENCE public.group_wallets_id_seq OWNED BY public.group_wallets.id;


--
-- Name: groups; Type: TABLE; Schema: public; Owner: gigzito
--

CREATE TABLE public.groups (
    id integer NOT NULL,
    name text NOT NULL,
    description text,
    cover_url text,
    is_private boolean DEFAULT true NOT NULL,
    invite_code text NOT NULL,
    created_by integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.groups OWNER TO gigzito;

--
-- Name: groups_id_seq; Type: SEQUENCE; Schema: public; Owner: gigzito
--

CREATE SEQUENCE public.groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.groups_id_seq OWNER TO gigzito;

--
-- Name: groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gigzito
--

ALTER SEQUENCE public.groups_id_seq OWNED BY public.groups.id;


--
-- Name: gz_band_events; Type: TABLE; Schema: public; Owner: gigzito
--

CREATE TABLE public.gz_band_events (
    id integer NOT NULL,
    band_id integer NOT NULL,
    title text NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    venue text,
    city text,
    start_at timestamp without time zone NOT NULL,
    end_at timestamp without time zone,
    ticket_url text,
    type text DEFAULT 'show'::text NOT NULL,
    created_by integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.gz_band_events OWNER TO gigzito;

--
-- Name: gz_band_events_id_seq; Type: SEQUENCE; Schema: public; Owner: gigzito
--

CREATE SEQUENCE public.gz_band_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gz_band_events_id_seq OWNER TO gigzito;

--
-- Name: gz_band_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gigzito
--

ALTER SEQUENCE public.gz_band_events_id_seq OWNED BY public.gz_band_events.id;


--
-- Name: gz_band_followers; Type: TABLE; Schema: public; Owner: gigzito
--

CREATE TABLE public.gz_band_followers (
    id integer NOT NULL,
    band_id integer NOT NULL,
    user_id integer,
    email text NOT NULL,
    display_name text,
    followed_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.gz_band_followers OWNER TO gigzito;

--
-- Name: gz_band_followers_id_seq; Type: SEQUENCE; Schema: public; Owner: gigzito
--

CREATE SEQUENCE public.gz_band_followers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gz_band_followers_id_seq OWNER TO gigzito;

--
-- Name: gz_band_followers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gigzito
--

ALTER SEQUENCE public.gz_band_followers_id_seq OWNED BY public.gz_band_followers.id;


--
-- Name: gz_band_members; Type: TABLE; Schema: public; Owner: gigzito
--

CREATE TABLE public.gz_band_members (
    id integer NOT NULL,
    band_id integer NOT NULL,
    user_id integer NOT NULL,
    role text DEFAULT 'member'::text NOT NULL,
    instrument text,
    joined_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.gz_band_members OWNER TO gigzito;

--
-- Name: gz_band_members_id_seq; Type: SEQUENCE; Schema: public; Owner: gigzito
--

CREATE SEQUENCE public.gz_band_members_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gz_band_members_id_seq OWNER TO gigzito;

--
-- Name: gz_band_members_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gigzito
--

ALTER SEQUENCE public.gz_band_members_id_seq OWNED BY public.gz_band_members.id;


--
-- Name: gz_band_photos; Type: TABLE; Schema: public; Owner: gigzito
--

CREATE TABLE public.gz_band_photos (
    id integer NOT NULL,
    band_id integer NOT NULL,
    url text NOT NULL,
    caption text,
    uploaded_by integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.gz_band_photos OWNER TO gigzito;

--
-- Name: gz_band_photos_id_seq; Type: SEQUENCE; Schema: public; Owner: gigzito
--

CREATE SEQUENCE public.gz_band_photos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gz_band_photos_id_seq OWNER TO gigzito;

--
-- Name: gz_band_photos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gigzito
--

ALTER SEQUENCE public.gz_band_photos_id_seq OWNED BY public.gz_band_photos.id;


--
-- Name: gz_band_roster; Type: TABLE; Schema: public; Owner: gigzito
--

CREATE TABLE public.gz_band_roster (
    id integer NOT NULL,
    band_id integer NOT NULL,
    name text NOT NULL,
    thumb_url text,
    bio text,
    role text,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.gz_band_roster OWNER TO gigzito;

--
-- Name: gz_band_roster_id_seq; Type: SEQUENCE; Schema: public; Owner: gigzito
--

CREATE SEQUENCE public.gz_band_roster_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gz_band_roster_id_seq OWNER TO gigzito;

--
-- Name: gz_band_roster_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gigzito
--

ALTER SEQUENCE public.gz_band_roster_id_seq OWNED BY public.gz_band_roster.id;


--
-- Name: gz_band_tv_shows; Type: TABLE; Schema: public; Owner: gigzito
--

CREATE TABLE public.gz_band_tv_shows (
    id integer NOT NULL,
    band_id integer NOT NULL,
    title text NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    stream_url text,
    thumbnail_url text,
    type text DEFAULT 'archived'::text NOT NULL,
    scheduled_at timestamp without time zone,
    duration_seconds integer,
    view_count integer DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.gz_band_tv_shows OWNER TO gigzito;

--
-- Name: gz_band_tv_shows_id_seq; Type: SEQUENCE; Schema: public; Owner: gigzito
--

CREATE SEQUENCE public.gz_band_tv_shows_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gz_band_tv_shows_id_seq OWNER TO gigzito;

--
-- Name: gz_band_tv_shows_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gigzito
--

ALTER SEQUENCE public.gz_band_tv_shows_id_seq OWNED BY public.gz_band_tv_shows.id;


--
-- Name: gz_band_wall_comments; Type: TABLE; Schema: public; Owner: gigzito
--

CREATE TABLE public.gz_band_wall_comments (
    id integer NOT NULL,
    post_id integer NOT NULL,
    user_id integer NOT NULL,
    content text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.gz_band_wall_comments OWNER TO gigzito;

--
-- Name: gz_band_wall_comments_id_seq; Type: SEQUENCE; Schema: public; Owner: gigzito
--

CREATE SEQUENCE public.gz_band_wall_comments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gz_band_wall_comments_id_seq OWNER TO gigzito;

--
-- Name: gz_band_wall_comments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gigzito
--

ALTER SEQUENCE public.gz_band_wall_comments_id_seq OWNED BY public.gz_band_wall_comments.id;


--
-- Name: gz_band_wall_post_likes; Type: TABLE; Schema: public; Owner: gigzito
--

CREATE TABLE public.gz_band_wall_post_likes (
    id integer NOT NULL,
    post_id integer NOT NULL,
    user_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.gz_band_wall_post_likes OWNER TO gigzito;

--
-- Name: gz_band_wall_post_likes_id_seq; Type: SEQUENCE; Schema: public; Owner: gigzito
--

CREATE SEQUENCE public.gz_band_wall_post_likes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gz_band_wall_post_likes_id_seq OWNER TO gigzito;

--
-- Name: gz_band_wall_post_likes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gigzito
--

ALTER SEQUENCE public.gz_band_wall_post_likes_id_seq OWNED BY public.gz_band_wall_post_likes.id;


--
-- Name: gz_band_wall_posts; Type: TABLE; Schema: public; Owner: gigzito
--

CREATE TABLE public.gz_band_wall_posts (
    id integer NOT NULL,
    band_id integer NOT NULL,
    user_id integer,
    content text NOT NULL,
    image_url text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    guest_name text,
    guest_email text,
    like_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.gz_band_wall_posts OWNER TO gigzito;

--
-- Name: gz_band_wall_posts_id_seq; Type: SEQUENCE; Schema: public; Owner: gigzito
--

CREATE SEQUENCE public.gz_band_wall_posts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gz_band_wall_posts_id_seq OWNER TO gigzito;

--
-- Name: gz_band_wall_posts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gigzito
--

ALTER SEQUENCE public.gz_band_wall_posts_id_seq OWNED BY public.gz_band_wall_posts.id;


--
-- Name: gz_bands; Type: TABLE; Schema: public; Owner: gigzito
--

CREATE TABLE public.gz_bands (
    id integer NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    bio text DEFAULT ''::text NOT NULL,
    genre text DEFAULT ''::text NOT NULL,
    avatar_url text,
    banner_url text,
    city text,
    state text,
    website_url text,
    instagram_url text,
    tiktok_url text,
    youtube_url text,
    live_stream_url text,
    is_live boolean DEFAULT false NOT NULL,
    created_by integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    band_type text DEFAULT 'band'::text NOT NULL,
    allow_guest_posts boolean DEFAULT false NOT NULL
);


ALTER TABLE public.gz_bands OWNER TO gigzito;

--
-- Name: gz_bands_id_seq; Type: SEQUENCE; Schema: public; Owner: gigzito
--

CREATE SEQUENCE public.gz_bands_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gz_bands_id_seq OWNER TO gigzito;

--
-- Name: gz_bands_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gigzito
--

ALTER SEQUENCE public.gz_bands_id_seq OWNED BY public.gz_bands.id;


--
-- Name: gz_flash_ads; Type: TABLE; Schema: public; Owner: gigzito
--

CREATE TABLE public.gz_flash_ads (
    id integer NOT NULL,
    user_id integer NOT NULL,
    title text NOT NULL,
    artwork_url text,
    retail_price_cents integer NOT NULL,
    discount_percent integer NOT NULL,
    quantity integer DEFAULT 10 NOT NULL,
    claimed_count integer DEFAULT 0 NOT NULL,
    duration_minutes integer NOT NULL,
    potency_score real DEFAULT 0 NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    display_mode text DEFAULT 'countdown'::text NOT NULL,
    admin_note text,
    coupon_code text,
    coupon_expiry_hours integer DEFAULT 48 NOT NULL
);


ALTER TABLE public.gz_flash_ads OWNER TO gigzito;

--
-- Name: gz_flash_ads_id_seq; Type: SEQUENCE; Schema: public; Owner: gigzito
--

CREATE SEQUENCE public.gz_flash_ads_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gz_flash_ads_id_seq OWNER TO gigzito;

--
-- Name: gz_flash_ads_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gigzito
--

ALTER SEQUENCE public.gz_flash_ads_id_seq OWNED BY public.gz_flash_ads.id;


--
-- Name: gz_flash_claims; Type: TABLE; Schema: public; Owner: gigzito
--

CREATE TABLE public.gz_flash_claims (
    id integer NOT NULL,
    flash_ad_id integer NOT NULL,
    email text NOT NULL,
    coupon_code text,
    claimed_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.gz_flash_claims OWNER TO gigzito;

--
-- Name: gz_flash_claims_id_seq; Type: SEQUENCE; Schema: public; Owner: gigzito
--

CREATE SEQUENCE public.gz_flash_claims_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gz_flash_claims_id_seq OWNER TO gigzito;

--
-- Name: gz_flash_claims_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gigzito
--

ALTER SEQUENCE public.gz_flash_claims_id_seq OWNED BY public.gz_flash_claims.id;


--
-- Name: gz_music_comments; Type: TABLE; Schema: public; Owner: gigzito
--

CREATE TABLE public.gz_music_comments (
    id integer NOT NULL,
    track_id integer NOT NULL,
    user_id integer NOT NULL,
    content text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.gz_music_comments OWNER TO gigzito;

--
-- Name: gz_music_comments_id_seq; Type: SEQUENCE; Schema: public; Owner: gigzito
--

CREATE SEQUENCE public.gz_music_comments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gz_music_comments_id_seq OWNER TO gigzito;

--
-- Name: gz_music_comments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gigzito
--

ALTER SEQUENCE public.gz_music_comments_id_seq OWNED BY public.gz_music_comments.id;


--
-- Name: gz_music_likes; Type: TABLE; Schema: public; Owner: gigzito
--

CREATE TABLE public.gz_music_likes (
    id integer NOT NULL,
    track_id integer NOT NULL,
    user_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.gz_music_likes OWNER TO gigzito;

--
-- Name: gz_music_likes_id_seq; Type: SEQUENCE; Schema: public; Owner: gigzito
--

CREATE SEQUENCE public.gz_music_likes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gz_music_likes_id_seq OWNER TO gigzito;

--
-- Name: gz_music_likes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gigzito
--

ALTER SEQUENCE public.gz_music_likes_id_seq OWNED BY public.gz_music_likes.id;


--
-- Name: gz_music_ratings; Type: TABLE; Schema: public; Owner: gigzito
--

CREATE TABLE public.gz_music_ratings (
    id integer NOT NULL,
    track_id integer NOT NULL,
    user_id integer NOT NULL,
    stars real NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.gz_music_ratings OWNER TO gigzito;

--
-- Name: gz_music_ratings_id_seq; Type: SEQUENCE; Schema: public; Owner: gigzito
--

CREATE SEQUENCE public.gz_music_ratings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gz_music_ratings_id_seq OWNER TO gigzito;

--
-- Name: gz_music_ratings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gigzito
--

ALTER SEQUENCE public.gz_music_ratings_id_seq OWNED BY public.gz_music_ratings.id;


--
-- Name: gz_music_tracks; Type: TABLE; Schema: public; Owner: gigzito
--

CREATE TABLE public.gz_music_tracks (
    id integer NOT NULL,
    title text NOT NULL,
    artist text NOT NULL,
    genre text DEFAULT ''::text NOT NULL,
    cover_url text,
    audio_url text,
    file_url text,
    license_file_url text,
    download_enabled boolean DEFAULT false NOT NULL,
    authenticity_confirmed boolean DEFAULT false NOT NULL,
    uploader_user_id integer,
    submitted_by integer,
    like_count integer DEFAULT 0 NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    play_count integer DEFAULT 0 NOT NULL,
    shared_to_library boolean DEFAULT true NOT NULL,
    band_id integer
);


ALTER TABLE public.gz_music_tracks OWNER TO gigzito;

--
-- Name: gz_music_tracks_id_seq; Type: SEQUENCE; Schema: public; Owner: gigzito
--

CREATE SEQUENCE public.gz_music_tracks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gz_music_tracks_id_seq OWNER TO gigzito;

--
-- Name: gz_music_tracks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gigzito
--

ALTER SEQUENCE public.gz_music_tracks_id_seq OWNED BY public.gz_music_tracks.id;


--
-- Name: injected_feeds; Type: TABLE; Schema: public; Owner: gigzito
--

CREATE TABLE public.injected_feeds (
    id integer NOT NULL,
    platform text NOT NULL,
    source_url text NOT NULL,
    display_title text,
    category text,
    inject_mode text DEFAULT 'fallback'::text NOT NULL,
    status text DEFAULT 'inactive'::text NOT NULL,
    starts_at timestamp without time zone,
    ends_at timestamp without time zone,
    created_by integer,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.injected_feeds OWNER TO gigzito;

--
-- Name: injected_feeds_id_seq; Type: SEQUENCE; Schema: public; Owner: gigzito
--

CREATE SEQUENCE public.injected_feeds_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.injected_feeds_id_seq OWNER TO gigzito;

--
-- Name: injected_feeds_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gigzito
--

ALTER SEQUENCE public.injected_feeds_id_seq OWNED BY public.injected_feeds.id;


--
-- Name: leads; Type: TABLE; Schema: public; Owner: gigzito
--

CREATE TABLE public.leads (
    id integer NOT NULL,
    video_id integer,
    creator_user_id integer,
    first_name text NOT NULL,
    email text,
    phone text,
    message text,
    video_title text,
    category text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    viewer_username text,
    viewer_city text,
    viewer_state text,
    viewer_country text
);


ALTER TABLE public.leads OWNER TO gigzito;

--
-- Name: leads_id_seq; Type: SEQUENCE; Schema: public; Owner: gigzito
--

CREATE SEQUENCE public.leads_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.leads_id_seq OWNER TO gigzito;

--
-- Name: leads_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gigzito
--

ALTER SEQUENCE public.leads_id_seq OWNED BY public.leads.id;


--
-- Name: listing_comments; Type: TABLE; Schema: public; Owner: gigzito
--

CREATE TABLE public.listing_comments (
    id integer NOT NULL,
    listing_id integer NOT NULL,
    author_user_id integer,
    author_name text DEFAULT 'Anonymous'::text NOT NULL,
    comment_text text NOT NULL,
    is_clean boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    is_read boolean DEFAULT false NOT NULL,
    viewer_username text,
    viewer_email text,
    viewer_city text,
    viewer_state text,
    viewer_country text
);


ALTER TABLE public.listing_comments OWNER TO gigzito;

--
-- Name: listing_comments_id_seq; Type: SEQUENCE; Schema: public; Owner: gigzito
--

CREATE SEQUENCE public.listing_comments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.listing_comments_id_seq OWNER TO gigzito;

--
-- Name: listing_comments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gigzito
--

ALTER SEQUENCE public.listing_comments_id_seq OWNED BY public.listing_comments.id;


--
-- Name: live_sessions; Type: TABLE; Schema: public; Owner: gigzito
--

CREATE TABLE public.live_sessions (
    id integer NOT NULL,
    creator_user_id integer NOT NULL,
    provider_id integer NOT NULL,
    title text NOT NULL,
    category text DEFAULT 'INFLUENCER'::text NOT NULL,
    mode text DEFAULT 'external'::text NOT NULL,
    platform text,
    stream_url text NOT NULL,
    thumbnail_url text,
    viewer_count integer DEFAULT 0 NOT NULL,
    tier_minutes integer DEFAULT 60 NOT NULL,
    tier_price_cents integer DEFAULT 2500 NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    started_at timestamp without time zone DEFAULT now() NOT NULL,
    ended_at timestamp without time zone
);


ALTER TABLE public.live_sessions OWNER TO gigzito;

--
-- Name: live_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: gigzito
--

CREATE SEQUENCE public.live_sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.live_sessions_id_seq OWNER TO gigzito;

--
-- Name: live_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gigzito
--

ALTER SEQUENCE public.live_sessions_id_seq OWNED BY public.live_sessions.id;


--
-- Name: love_votes; Type: TABLE; Schema: public; Owner: gigzito
--

CREATE TABLE public.love_votes (
    id integer NOT NULL,
    voter_user_id integer NOT NULL,
    provider_id integer NOT NULL,
    month_key text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.love_votes OWNER TO gigzito;

--
-- Name: love_votes_id_seq; Type: SEQUENCE; Schema: public; Owner: gigzito
--

CREATE SEQUENCE public.love_votes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.love_votes_id_seq OWNER TO gigzito;

--
-- Name: love_votes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gigzito
--

ALTER SEQUENCE public.love_votes_id_seq OWNED BY public.love_votes.id;


--
-- Name: marketer_audiences; Type: TABLE; Schema: public; Owner: gigzito
--

CREATE TABLE public.marketer_audiences (
    id integer NOT NULL,
    provider_user_id integer NOT NULL,
    lead_name text NOT NULL,
    lead_email text NOT NULL,
    lead_phone text,
    source_listing_id integer,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.marketer_audiences OWNER TO gigzito;

--
-- Name: marketer_audiences_id_seq; Type: SEQUENCE; Schema: public; Owner: gigzito
--

CREATE SEQUENCE public.marketer_audiences_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.marketer_audiences_id_seq OWNER TO gigzito;

--
-- Name: marketer_audiences_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gigzito
--

ALTER SEQUENCE public.marketer_audiences_id_seq OWNED BY public.marketer_audiences.id;


--
-- Name: mfa_codes; Type: TABLE; Schema: public; Owner: gigzito
--

CREATE TABLE public.mfa_codes (
    id integer NOT NULL,
    user_id integer NOT NULL,
    code text NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    used_at timestamp without time zone,
    resend_count integer DEFAULT 0 NOT NULL,
    last_resend_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.mfa_codes OWNER TO gigzito;

--
-- Name: mfa_codes_id_seq; Type: SEQUENCE; Schema: public; Owner: gigzito
--

CREATE SEQUENCE public.mfa_codes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.mfa_codes_id_seq OWNER TO gigzito;

--
-- Name: mfa_codes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gigzito
--

ALTER SEQUENCE public.mfa_codes_id_seq OWNED BY public.mfa_codes.id;


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: gigzito
--

CREATE TABLE public.notifications (
    id integer NOT NULL,
    user_id integer NOT NULL,
    type text NOT NULL,
    title text NOT NULL,
    message text NOT NULL,
    link text,
    is_read boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.notifications OWNER TO gigzito;

--
-- Name: notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: gigzito
--

CREATE SEQUENCE public.notifications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.notifications_id_seq OWNER TO gigzito;

--
-- Name: notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gigzito
--

ALTER SEQUENCE public.notifications_id_seq OWNED BY public.notifications.id;


--
-- Name: presenter_contacts; Type: TABLE; Schema: public; Owner: gigzito
--

CREATE TABLE public.presenter_contacts (
    id integer NOT NULL,
    presenter_user_id integer NOT NULL,
    member_user_id integer NOT NULL,
    opted_in_at timestamp without time zone DEFAULT now() NOT NULL,
    active boolean DEFAULT true NOT NULL,
    opted_out_at timestamp without time zone
);


ALTER TABLE public.presenter_contacts OWNER TO gigzito;

--
-- Name: presenter_contacts_id_seq; Type: SEQUENCE; Schema: public; Owner: gigzito
--

CREATE SEQUENCE public.presenter_contacts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.presenter_contacts_id_seq OWNER TO gigzito;

--
-- Name: presenter_contacts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gigzito
--

ALTER SEQUENCE public.presenter_contacts_id_seq OWNED BY public.presenter_contacts.id;


--
-- Name: profile_wall_posts; Type: TABLE; Schema: public; Owner: gigzito
--

CREATE TABLE public.profile_wall_posts (
    id integer NOT NULL,
    profile_id integer NOT NULL,
    author_user_id integer,
    author_name text DEFAULT 'Anonymous'::text NOT NULL,
    author_avatar text,
    message text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.profile_wall_posts OWNER TO gigzito;

--
-- Name: profile_wall_posts_id_seq; Type: SEQUENCE; Schema: public; Owner: gigzito
--

CREATE SEQUENCE public.profile_wall_posts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.profile_wall_posts_id_seq OWNER TO gigzito;

--
-- Name: profile_wall_posts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gigzito
--

ALTER SEQUENCE public.profile_wall_posts_id_seq OWNED BY public.profile_wall_posts.id;


--
-- Name: provider_profiles; Type: TABLE; Schema: public; Owner: gigzito
--

CREATE TABLE public.provider_profiles (
    id integer NOT NULL,
    user_id integer NOT NULL,
    display_name text DEFAULT ''::text NOT NULL,
    bio text DEFAULT ''::text NOT NULL,
    avatar_url text DEFAULT ''::text NOT NULL,
    thumb_url text DEFAULT ''::text NOT NULL,
    contact_email text,
    contact_phone text,
    contact_telegram text,
    website_url text,
    username text,
    primary_category text,
    location text,
    instagram_url text,
    youtube_url text,
    tiktok_url text,
    facebook_url text,
    discord_url text,
    twitter_url text,
    photo1_url text,
    photo2_url text,
    photo3_url text,
    photo4_url text,
    photo5_url text,
    photo6_url text,
    webhook_url text,
    ad_format text,
    show_phone boolean DEFAULT false NOT NULL
);


ALTER TABLE public.provider_profiles OWNER TO gigzito;

--
-- Name: provider_profiles_id_seq; Type: SEQUENCE; Schema: public; Owner: gigzito
--

CREATE SEQUENCE public.provider_profiles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.provider_profiles_id_seq OWNER TO gigzito;

--
-- Name: provider_profiles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gigzito
--

ALTER SEQUENCE public.provider_profiles_id_seq OWNED BY public.provider_profiles.id;


--
-- Name: session; Type: TABLE; Schema: public; Owner: gigzito
--

CREATE TABLE public.session (
    sid character varying NOT NULL,
    sess json NOT NULL,
    expire timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.session OWNER TO gigzito;

--
-- Name: sponsor_ads; Type: TABLE; Schema: public; Owner: gigzito
--

CREATE TABLE public.sponsor_ads (
    id integer NOT NULL,
    title text NOT NULL,
    body text DEFAULT ''::text NOT NULL,
    image_url text NOT NULL,
    target_url text NOT NULL,
    cta text DEFAULT 'Learn More'::text NOT NULL,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_by integer,
    cta_mode text DEFAULT 'url'::text NOT NULL,
    contact_username text,
    contact_email text,
    contact_message text,
    ad_format text DEFAULT 'TEXT'::text NOT NULL,
    video_url text
);


ALTER TABLE public.sponsor_ads OWNER TO gigzito;

--
-- Name: sponsor_ads_id_seq; Type: SEQUENCE; Schema: public; Owner: gigzito
--

CREATE SEQUENCE public.sponsor_ads_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sponsor_ads_id_seq OWNER TO gigzito;

--
-- Name: sponsor_ads_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gigzito
--

ALTER SEQUENCE public.sponsor_ads_id_seq OWNED BY public.sponsor_ads.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: gigzito
--

CREATE TABLE public.users (
    id integer NOT NULL,
    email text NOT NULL,
    password text NOT NULL,
    role public.role DEFAULT 'VISITOR'::public.role NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    disclaimer_accepted boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    deleted_at timestamp without time zone,
    email_verified boolean DEFAULT false NOT NULL,
    email_verification_token text,
    email_verification_expires_at timestamp without time zone,
    password_reset_token text,
    password_reset_expires_at timestamp without time zone,
    subscription_tier public.subscription_tier DEFAULT 'GZLurker'::public.subscription_tier NOT NULL,
    groups_enabled boolean DEFAULT false NOT NULL
);


ALTER TABLE public.users OWNER TO gigzito;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: gigzito
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO gigzito;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gigzito
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: video_likes; Type: TABLE; Schema: public; Owner: gigzito
--

CREATE TABLE public.video_likes (
    id integer NOT NULL,
    video_id integer NOT NULL,
    user_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.video_likes OWNER TO gigzito;

--
-- Name: video_likes_id_seq; Type: SEQUENCE; Schema: public; Owner: gigzito
--

CREATE SEQUENCE public.video_likes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.video_likes_id_seq OWNER TO gigzito;

--
-- Name: video_likes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gigzito
--

ALTER SEQUENCE public.video_likes_id_seq OWNED BY public.video_likes.id;


--
-- Name: video_listings; Type: TABLE; Schema: public; Owner: gigzito
--

CREATE TABLE public.video_listings (
    id integer NOT NULL,
    provider_id integer NOT NULL,
    vertical public.vertical NOT NULL,
    title text NOT NULL,
    video_url text,
    duration_seconds integer,
    description text,
    tags text[] DEFAULT '{}'::text[] NOT NULL,
    cta_label text,
    cta_url text,
    cta_type text,
    flash_sale_ends_at timestamp without time zone,
    coupon_code text,
    product_price text,
    product_purchase_url text,
    product_stock text,
    status public.listing_status DEFAULT 'ACTIVE'::public.listing_status NOT NULL,
    drop_date date NOT NULL,
    price_paid_cents integer DEFAULT 300 NOT NULL,
    stripe_session_id text,
    triaged_at timestamp without time zone,
    triaged_by integer,
    triaged_reason text,
    like_count integer DEFAULT 0 NOT NULL,
    reveal_url boolean DEFAULT true NOT NULL,
    reveal_email boolean DEFAULT false NOT NULL,
    reveal_name boolean DEFAULT false NOT NULL,
    collect_email boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    scan_status text DEFAULT 'CLEAN'::text NOT NULL,
    scan_note text,
    post_type text DEFAULT 'VIDEO'::text NOT NULL,
    bg_music_track_id integer,
    bg_music_volume integer DEFAULT 70 NOT NULL,
    custom_vertical text
);


ALTER TABLE public.video_listings OWNER TO gigzito;

--
-- Name: video_listings_id_seq; Type: SEQUENCE; Schema: public; Owner: gigzito
--

CREATE SEQUENCE public.video_listings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.video_listings_id_seq OWNER TO gigzito;

--
-- Name: video_listings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gigzito
--

ALTER SEQUENCE public.video_listings_id_seq OWNED BY public.video_listings.id;


--
-- Name: zee_motion_comments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.zee_motion_comments (
    id integer NOT NULL,
    motion_id integer NOT NULL,
    author_user_id integer,
    author_name text NOT NULL,
    comment_text text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.zee_motion_comments OWNER TO postgres;

--
-- Name: zee_motion_comments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.zee_motion_comments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.zee_motion_comments_id_seq OWNER TO postgres;

--
-- Name: zee_motion_comments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.zee_motion_comments_id_seq OWNED BY public.zee_motion_comments.id;


--
-- Name: zee_motions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.zee_motions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    text text,
    media_url text,
    media_type text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.zee_motions OWNER TO postgres;

--
-- Name: zee_motions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.zee_motions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.zee_motions_id_seq OWNER TO postgres;

--
-- Name: zee_motions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.zee_motions_id_seq OWNED BY public.zee_motions.id;


--
-- Name: zito_tv_events; Type: TABLE; Schema: public; Owner: gigzito
--

CREATE TABLE public.zito_tv_events (
    id integer NOT NULL,
    title text NOT NULL,
    description text,
    host_name text NOT NULL,
    host_user_id integer,
    category text DEFAULT 'OTHER'::text NOT NULL,
    live_url text,
    cta_url text,
    cover_image_url text,
    duration_minutes integer DEFAULT 60 NOT NULL,
    start_at timestamp without time zone NOT NULL,
    end_at timestamp without time zone NOT NULL,
    status text DEFAULT 'scheduled'::text NOT NULL,
    created_by integer,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.zito_tv_events OWNER TO gigzito;

--
-- Name: zito_tv_events_id_seq; Type: SEQUENCE; Schema: public; Owner: gigzito
--

CREATE SEQUENCE public.zito_tv_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.zito_tv_events_id_seq OWNER TO gigzito;

--
-- Name: zito_tv_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gigzito
--

ALTER SEQUENCE public.zito_tv_events_id_seq OWNED BY public.zito_tv_events.id;


--
-- Name: ad_bookings id; Type: DEFAULT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.ad_bookings ALTER COLUMN id SET DEFAULT nextval('public.ad_bookings_id_seq'::regclass);


--
-- Name: ad_inquiries id; Type: DEFAULT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.ad_inquiries ALTER COLUMN id SET DEFAULT nextval('public.ad_inquiries_id_seq'::regclass);


--
-- Name: all_eyes_slots id; Type: DEFAULT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.all_eyes_slots ALTER COLUMN id SET DEFAULT nextval('public.all_eyes_slots_id_seq'::regclass);


--
-- Name: audience_broadcasts id; Type: DEFAULT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.audience_broadcasts ALTER COLUMN id SET DEFAULT nextval('public.audience_broadcasts_id_seq'::regclass);


--
-- Name: audit_logs id; Type: DEFAULT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.audit_logs ALTER COLUMN id SET DEFAULT nextval('public.audit_logs_id_seq'::regclass);


--
-- Name: card_messages id; Type: DEFAULT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.card_messages ALTER COLUMN id SET DEFAULT nextval('public.card_messages_id_seq'::regclass);


--
-- Name: geezee_follows id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.geezee_follows ALTER COLUMN id SET DEFAULT nextval('public.geezee_follows_id_seq'::regclass);


--
-- Name: geo_target_campaigns id; Type: DEFAULT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.geo_target_campaigns ALTER COLUMN id SET DEFAULT nextval('public.geo_target_campaigns_id_seq'::regclass);


--
-- Name: gig_jacks id; Type: DEFAULT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.gig_jacks ALTER COLUMN id SET DEFAULT nextval('public.gig_jacks_id_seq'::regclass);


--
-- Name: gigness_card_comments id; Type: DEFAULT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.gigness_card_comments ALTER COLUMN id SET DEFAULT nextval('public.gigness_card_comments_id_seq'::regclass);


--
-- Name: gigness_cards id; Type: DEFAULT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.gigness_cards ALTER COLUMN id SET DEFAULT nextval('public.gigness_cards_id_seq'::regclass);


--
-- Name: group_email_invites id; Type: DEFAULT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.group_email_invites ALTER COLUMN id SET DEFAULT nextval('public.group_email_invites_id_seq'::regclass);


--
-- Name: group_endeavors id; Type: DEFAULT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.group_endeavors ALTER COLUMN id SET DEFAULT nextval('public.group_endeavors_id_seq'::regclass);


--
-- Name: group_events id; Type: DEFAULT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.group_events ALTER COLUMN id SET DEFAULT nextval('public.group_events_id_seq'::regclass);


--
-- Name: group_kanban_cards id; Type: DEFAULT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.group_kanban_cards ALTER COLUMN id SET DEFAULT nextval('public.group_kanban_cards_id_seq'::regclass);


--
-- Name: group_members id; Type: DEFAULT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.group_members ALTER COLUMN id SET DEFAULT nextval('public.group_members_id_seq'::regclass);


--
-- Name: group_wall_comments id; Type: DEFAULT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.group_wall_comments ALTER COLUMN id SET DEFAULT nextval('public.group_wall_comments_id_seq'::regclass);


--
-- Name: group_wall_posts id; Type: DEFAULT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.group_wall_posts ALTER COLUMN id SET DEFAULT nextval('public.group_wall_posts_id_seq'::regclass);


--
-- Name: group_wallet_contributions id; Type: DEFAULT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.group_wallet_contributions ALTER COLUMN id SET DEFAULT nextval('public.group_wallet_contributions_id_seq'::regclass);


--
-- Name: group_wallets id; Type: DEFAULT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.group_wallets ALTER COLUMN id SET DEFAULT nextval('public.group_wallets_id_seq'::regclass);


--
-- Name: groups id; Type: DEFAULT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.groups ALTER COLUMN id SET DEFAULT nextval('public.groups_id_seq'::regclass);


--
-- Name: gz_band_events id; Type: DEFAULT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.gz_band_events ALTER COLUMN id SET DEFAULT nextval('public.gz_band_events_id_seq'::regclass);


--
-- Name: gz_band_followers id; Type: DEFAULT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.gz_band_followers ALTER COLUMN id SET DEFAULT nextval('public.gz_band_followers_id_seq'::regclass);


--
-- Name: gz_band_members id; Type: DEFAULT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.gz_band_members ALTER COLUMN id SET DEFAULT nextval('public.gz_band_members_id_seq'::regclass);


--
-- Name: gz_band_photos id; Type: DEFAULT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.gz_band_photos ALTER COLUMN id SET DEFAULT nextval('public.gz_band_photos_id_seq'::regclass);


--
-- Name: gz_band_roster id; Type: DEFAULT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.gz_band_roster ALTER COLUMN id SET DEFAULT nextval('public.gz_band_roster_id_seq'::regclass);


--
-- Name: gz_band_tv_shows id; Type: DEFAULT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.gz_band_tv_shows ALTER COLUMN id SET DEFAULT nextval('public.gz_band_tv_shows_id_seq'::regclass);


--
-- Name: gz_band_wall_comments id; Type: DEFAULT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.gz_band_wall_comments ALTER COLUMN id SET DEFAULT nextval('public.gz_band_wall_comments_id_seq'::regclass);


--
-- Name: gz_band_wall_post_likes id; Type: DEFAULT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.gz_band_wall_post_likes ALTER COLUMN id SET DEFAULT nextval('public.gz_band_wall_post_likes_id_seq'::regclass);


--
-- Name: gz_band_wall_posts id; Type: DEFAULT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.gz_band_wall_posts ALTER COLUMN id SET DEFAULT nextval('public.gz_band_wall_posts_id_seq'::regclass);


--
-- Name: gz_bands id; Type: DEFAULT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.gz_bands ALTER COLUMN id SET DEFAULT nextval('public.gz_bands_id_seq'::regclass);


--
-- Name: gz_flash_ads id; Type: DEFAULT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.gz_flash_ads ALTER COLUMN id SET DEFAULT nextval('public.gz_flash_ads_id_seq'::regclass);


--
-- Name: gz_flash_claims id; Type: DEFAULT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.gz_flash_claims ALTER COLUMN id SET DEFAULT nextval('public.gz_flash_claims_id_seq'::regclass);


--
-- Name: gz_music_comments id; Type: DEFAULT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.gz_music_comments ALTER COLUMN id SET DEFAULT nextval('public.gz_music_comments_id_seq'::regclass);


--
-- Name: gz_music_likes id; Type: DEFAULT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.gz_music_likes ALTER COLUMN id SET DEFAULT nextval('public.gz_music_likes_id_seq'::regclass);


--
-- Name: gz_music_ratings id; Type: DEFAULT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.gz_music_ratings ALTER COLUMN id SET DEFAULT nextval('public.gz_music_ratings_id_seq'::regclass);


--
-- Name: gz_music_tracks id; Type: DEFAULT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.gz_music_tracks ALTER COLUMN id SET DEFAULT nextval('public.gz_music_tracks_id_seq'::regclass);


--
-- Name: injected_feeds id; Type: DEFAULT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.injected_feeds ALTER COLUMN id SET DEFAULT nextval('public.injected_feeds_id_seq'::regclass);


--
-- Name: leads id; Type: DEFAULT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.leads ALTER COLUMN id SET DEFAULT nextval('public.leads_id_seq'::regclass);


--
-- Name: listing_comments id; Type: DEFAULT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.listing_comments ALTER COLUMN id SET DEFAULT nextval('public.listing_comments_id_seq'::regclass);


--
-- Name: live_sessions id; Type: DEFAULT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.live_sessions ALTER COLUMN id SET DEFAULT nextval('public.live_sessions_id_seq'::regclass);


--
-- Name: love_votes id; Type: DEFAULT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.love_votes ALTER COLUMN id SET DEFAULT nextval('public.love_votes_id_seq'::regclass);


--
-- Name: marketer_audiences id; Type: DEFAULT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.marketer_audiences ALTER COLUMN id SET DEFAULT nextval('public.marketer_audiences_id_seq'::regclass);


--
-- Name: mfa_codes id; Type: DEFAULT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.mfa_codes ALTER COLUMN id SET DEFAULT nextval('public.mfa_codes_id_seq'::regclass);


--
-- Name: notifications id; Type: DEFAULT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.notifications ALTER COLUMN id SET DEFAULT nextval('public.notifications_id_seq'::regclass);


--
-- Name: presenter_contacts id; Type: DEFAULT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.presenter_contacts ALTER COLUMN id SET DEFAULT nextval('public.presenter_contacts_id_seq'::regclass);


--
-- Name: profile_wall_posts id; Type: DEFAULT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.profile_wall_posts ALTER COLUMN id SET DEFAULT nextval('public.profile_wall_posts_id_seq'::regclass);


--
-- Name: provider_profiles id; Type: DEFAULT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.provider_profiles ALTER COLUMN id SET DEFAULT nextval('public.provider_profiles_id_seq'::regclass);


--
-- Name: sponsor_ads id; Type: DEFAULT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.sponsor_ads ALTER COLUMN id SET DEFAULT nextval('public.sponsor_ads_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: video_likes id; Type: DEFAULT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.video_likes ALTER COLUMN id SET DEFAULT nextval('public.video_likes_id_seq'::regclass);


--
-- Name: video_listings id; Type: DEFAULT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.video_listings ALTER COLUMN id SET DEFAULT nextval('public.video_listings_id_seq'::regclass);


--
-- Name: zee_motion_comments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.zee_motion_comments ALTER COLUMN id SET DEFAULT nextval('public.zee_motion_comments_id_seq'::regclass);


--
-- Name: zee_motions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.zee_motions ALTER COLUMN id SET DEFAULT nextval('public.zee_motions_id_seq'::regclass);


--
-- Name: zito_tv_events id; Type: DEFAULT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.zito_tv_events ALTER COLUMN id SET DEFAULT nextval('public.zito_tv_events_id_seq'::regclass);


--
-- Data for Name: ad_bookings; Type: TABLE DATA; Schema: public; Owner: gigzito
--

COPY public.ad_bookings (id, sponsor_ad_id, booking_date, slot_number, advertiser_name, advertiser_email, status, amount_cents, notes, created_at) FROM stdin;
\.


--
-- Data for Name: ad_inquiries; Type: TABLE DATA; Schema: public; Owner: gigzito
--

COPY public.ad_inquiries (id, ad_id, advertiser_username, viewer_name, viewer_email, viewer_message, created_at, viewer_username, viewer_city, viewer_state, viewer_country, is_read) FROM stdin;
6	8	admin	brandon	brandonspower@gmail.com	test	2026-03-15 22:06:11.677374+00	admin	Glendale	Arizona	United States	t
5	8	admin	bradon	admin@gigzito.com	this is a test	2026-03-15 22:01:30.183022+00	admin	Glendale	Arizona	United States	t
4	8	admin	brandon	brandonspower@gmail.com	need to know	2026-03-15 21:59:22.086216+00	\N	Glendale	Arizona	United States	t
3	8	admin	josh	josh@gigzito.com	test	2026-03-15 21:46:40.05728+00	joshie	Glendale	Arizona	United States	t
2	8	admin	Brandon Leal	brandonspower@gmail.com	does this work?	2026-03-15 20:17:59.685521+00	\N	\N	\N	\N	t
1	8	admin	josh	josh@gigzito.com	please let know deekhead	2026-03-15 20:00:27.287352+00	\N	\N	\N	\N	t
7	8	admin	brandon	yahstone@gmail.com	how's going	2026-03-15 23:46:05.528809+00	admin	Glendale	Arizona	United States	t
8	8	admin	the dude	yahstone@gmail.com	whats up with this	2026-03-16 12:17:42.762809+00	admin	Glendale	Arizona	United States	f
\.


--
-- Data for Name: all_eyes_slots; Type: TABLE DATA; Schema: public; Owner: gigzito
--

COPY public.all_eyes_slots (id, provider_id, video_listing_id, custom_title, duration_minutes, start_at, end_at, status, price_cents, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: audience_broadcasts; Type: TABLE DATA; Schema: public; Owner: gigzito
--

COPY public.audience_broadcasts (id, provider_user_id, subject, body, recipient_count, sent_at) FROM stdin;
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: gigzito
--

COPY public.audit_logs (id, actor_user_id, action_type, target_type, target_id, old_value, new_value, used_override, created_at) FROM stdin;
1	7	USER_PROFILE_EDIT	USER	8	\N	\N	f	2026-03-16 02:58:42.579399
2	7	SUBSCRIPTION_TIER_CHANGE	USER	8	\N	\N	f	2026-03-16 02:58:58.646413
3	7	SUBSCRIPTION_TIER_CHANGE	USER	17	\N	\N	f	2026-03-18 20:33:33.530824
4	7	SUBSCRIPTION_TIER_CHANGE	USER	13	\N	\N	f	2026-03-18 20:33:39.272852
5	7	SUBSCRIPTION_TIER_CHANGE	USER	18	\N	\N	f	2026-03-19 20:16:29.706707
6	7	SUBSCRIPTION_TIER_CHANGE	USER	16	\N	\N	f	2026-03-19 23:24:31.221011
7	7	SUBSCRIPTION_TIER_CHANGE	USER	19	\N	\N	f	2026-03-22 17:05:52.775173
8	7	SUBSCRIPTION_TIER_CHANGE	USER	15	\N	\N	f	2026-03-22 17:09:45.720862
9	7	SUBSCRIPTION_TIER_CHANGE	USER	20	\N	\N	f	2026-04-12 23:02:07.017333
10	7	SUBSCRIPTION_TIER_CHANGE	USER	14	\N	\N	f	2026-04-12 23:02:28.344703
11	7	SUBSCRIPTION_TIER_CHANGE	USER	9	\N	\N	f	2026-04-12 23:03:20.761178
\.


--
-- Data for Name: card_messages; Type: TABLE DATA; Schema: public; Owner: gigzito
--

COPY public.card_messages (id, from_user_id, to_user_id, gigness_card_id, message_text, emoji_reaction, is_clean, created_at, is_read) FROM stdin;
1	9	17	1	this is your friend Brandon . Testing	\N	t	2026-03-17 04:27:42.053831	f
2	9	17	1	can you see this?	🔥	t	2026-04-14 15:31:43.824773	f
\.


--
-- Data for Name: geezee_follows; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.geezee_follows (id, follower_id, following_user_id, created_at) FROM stdin;
1	9	17	2026-03-17 03:22:41.66408
2	9	13	2026-04-14 15:52:04.824583
\.


--
-- Data for Name: geo_target_campaigns; Type: TABLE DATA; Schema: public; Owner: gigzito
--

COPY public.geo_target_campaigns (id, provider_user_id, title, offer, radius_miles, city, state, country, lat, lng, image_url, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: gig_jacks; Type: TABLE DATA; Schema: public; Owner: gigzito
--

COPY public.gig_jacks (id, provider_id, company_url, artwork_url, offer_title, description, cta_link, countdown_minutes, coupon_code, quantity_limit, tagline, category, scheduled_at, booked_date, booked_hour, flash_duration_seconds, offer_duration_minutes, status, display_state, siren_enabled, review_note, bot_warning, bot_warning_message, approved_at, approved_by, denied_at, denied_by, removed_at, removed_by, flash_started_at, flash_ended_at, offer_started_at, offer_ends_at, completed_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: gigness_card_comments; Type: TABLE DATA; Schema: public; Owner: gigzito
--

COPY public.gigness_card_comments (id, card_id, author_user_id, author_name, comment_text, is_clean, created_at) FROM stdin;
1	1	9	Anonymous	Great Looking profile!	t	2026-03-17 03:53:13.173929
\.


--
-- Data for Name: gigness_cards; Type: TABLE DATA; Schema: public; Owner: gigzito
--

COPY public.gigness_cards (id, user_id, qr_uuid, slogan, profile_pic, gallery, is_public, age_bracket, gender, intent, engagement_count, created_at, updated_at, location_services_enabled, allow_messaging, show_social_links) FROM stdin;
16	19	5c0a6419-cd82-4d65-9b6d-29a83e8d4e44	Sharing my journey of transformation to show others it can be done	/uploads/1774196269650-4285dab23a28.jpeg	{}	t	\N	\N	\N	1	2026-03-22 16:18:39.50954	2026-03-22 17:22:21.566	f	t	f
10	13	d057e97f-51f5-4176-a47c-9fec66b888e9	Lets grow together!	/uploads/1773795037353-5fc8447b60fb.png	{/uploads/1773795094754-a536ab09c4ce.png,/uploads/1773795114079-4cdba25e357d.png,/uploads/1773795138199-abb1646bdada.png,/uploads/1773795156767-86cf8e3eaf9e.png}	t	18-25	\N	marketing	2	2026-03-18 00:50:57.435868	2026-03-18 03:47:04.383	f	t	f
1	17	74669815-f5f9-4c01-bec9-f00753f2c6d7	Here for the party	/uploads/1773716182120-07a8840882ad.jpg	{/uploads/1773713045269-e9d34c971ed8.jpg,/uploads/1773713105441-55b75d90bca5.jpg,/uploads/1773713115301-8c7bdab3b076.jpg}	t	40+	Female	social	4	2026-03-17 00:24:11.657254	2026-03-17 02:56:28.034	f	t	f
2	9	d3ae68e5-5407-452e-b90c-667192a13719	This is really cool\n	/uploads/1773717554703-ccb98cc95af3.png	{/uploads/1773710302958-625ba41e2fd2.png,/uploads/1773710307894-365db1036397.png,/uploads/1773710313404-38e0f5bbaad8.png,/uploads/1773710319295-8664639d5f6e.png,/uploads/1773710325542-0d1a6e3e3381.png,/uploads/1773710334786-449276bb4d88.jpg}	t	40+	Male	\N	0	2026-03-17 01:18:58.187156	2026-03-17 03:34:54.242	f	t	f
\.


--
-- Data for Name: group_email_invites; Type: TABLE DATA; Schema: public; Owner: gigzito
--

COPY public.group_email_invites (id, group_id, email, token, invited_by, group_name, inviter_name, created_at, expires_at, claimed_by, claimed_at) FROM stdin;
\.


--
-- Data for Name: group_endeavors; Type: TABLE DATA; Schema: public; Owner: gigzito
--

COPY public.group_endeavors (id, group_id, title, description, goal_progress, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: group_events; Type: TABLE DATA; Schema: public; Owner: gigzito
--

COPY public.group_events (id, group_id, title, description, start_at, end_at, all_day, created_by, created_at) FROM stdin;
1	6	Test Event	we need fund raise asap	2026-03-23 07:00:00+00	\N	f	9	2026-03-22 22:23:47.137117+00
\.


--
-- Data for Name: group_kanban_cards; Type: TABLE DATA; Schema: public; Owner: gigzito
--

COPY public.group_kanban_cards (id, group_id, title, description, status, "position", created_by, created_at) FROM stdin;
1	6	test card 1	this is a test\n	done	0	9	2026-03-30 02:27:10.066957+00
\.


--
-- Data for Name: group_members; Type: TABLE DATA; Schema: public; Owner: gigzito
--

COPY public.group_members (id, group_id, user_id, role, status, invited_by, joined_at, created_at) FROM stdin;
1	6	9	admin	accepted	\N	2026-03-22 22:21:39.848829+00	2026-03-22 22:21:39.848829
\.


--
-- Data for Name: group_wall_comments; Type: TABLE DATA; Schema: public; Owner: gigzito
--

COPY public.group_wall_comments (id, post_id, group_id, user_id, content, created_at) FROM stdin;
\.


--
-- Data for Name: group_wall_posts; Type: TABLE DATA; Schema: public; Owner: gigzito
--

COPY public.group_wall_posts (id, group_id, user_id, content, created_at) FROM stdin;
\.


--
-- Data for Name: group_wallet_contributions; Type: TABLE DATA; Schema: public; Owner: gigzito
--

COPY public.group_wallet_contributions (id, wallet_id, group_id, user_id, amount, currency, tx_hash, note, display_name, created_at) FROM stdin;
\.


--
-- Data for Name: group_wallets; Type: TABLE DATA; Schema: public; Owner: gigzito
--

COPY public.group_wallets (id, group_id, label, network, address, link, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: groups; Type: TABLE DATA; Schema: public; Owner: gigzito
--

COPY public.groups (id, name, description, cover_url, is_private, invite_code, created_by, created_at) FROM stdin;
1	Marketing Minds Phoenix	Like minded marketers alike.	\N	t	XVXH7X	9	2026-03-22 21:11:12.229011+00
2	Marketing Minds Phoenix	Like minded marketers alike.	\N	t	QQ6WVF	9	2026-03-22 21:11:23.166437+00
3	GZMastermind	This is a secret GZ group : )	\N	t	MOMR6E	9	2026-03-22 21:59:22.85731+00
4	GZMastermind	This is a secret GZ group : )	\N	t	AP7GV3	9	2026-03-22 21:59:25.33408+00
5	GZMastermind	This is a secret GZ group : )	\N	t	351LMW	9	2026-03-22 21:59:28.302394+00
6	GZMasterMind	Hint: If you want to make money, this is the ultra secret GZ original. We know a guy : ) or gal : )	\N	t	7VRI9T	9	2026-03-22 22:21:39.846095+00
\.


--
-- Data for Name: gz_band_events; Type: TABLE DATA; Schema: public; Owner: gigzito
--

COPY public.gz_band_events (id, band_id, title, description, venue, city, start_at, end_at, ticket_url, type, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: gz_band_followers; Type: TABLE DATA; Schema: public; Owner: gigzito
--

COPY public.gz_band_followers (id, band_id, user_id, email, display_name, followed_at) FROM stdin;
\.


--
-- Data for Name: gz_band_members; Type: TABLE DATA; Schema: public; Owner: gigzito
--

COPY public.gz_band_members (id, band_id, user_id, role, instrument, joined_at) FROM stdin;
1	1	9	admin	\N	2026-04-16 03:16:47.558344
\.


--
-- Data for Name: gz_band_photos; Type: TABLE DATA; Schema: public; Owner: gigzito
--

COPY public.gz_band_photos (id, band_id, url, caption, uploaded_by, created_at) FROM stdin;
\.


--
-- Data for Name: gz_band_roster; Type: TABLE DATA; Schema: public; Owner: gigzito
--

COPY public.gz_band_roster (id, band_id, name, thumb_url, bio, role, sort_order, created_at) FROM stdin;
\.


--
-- Data for Name: gz_band_tv_shows; Type: TABLE DATA; Schema: public; Owner: gigzito
--

COPY public.gz_band_tv_shows (id, band_id, title, description, stream_url, thumbnail_url, type, scheduled_at, duration_seconds, view_count, created_at) FROM stdin;
\.


--
-- Data for Name: gz_band_wall_comments; Type: TABLE DATA; Schema: public; Owner: gigzito
--

COPY public.gz_band_wall_comments (id, post_id, user_id, content, created_at) FROM stdin;
\.


--
-- Data for Name: gz_band_wall_post_likes; Type: TABLE DATA; Schema: public; Owner: gigzito
--

COPY public.gz_band_wall_post_likes (id, post_id, user_id, created_at) FROM stdin;
\.


--
-- Data for Name: gz_band_wall_posts; Type: TABLE DATA; Schema: public; Owner: gigzito
--

COPY public.gz_band_wall_posts (id, band_id, user_id, content, image_url, created_at, guest_name, guest_email, like_count) FROM stdin;
1	1	9	This is a test 1	\N	2026-04-16 15:01:39.3177	\N	\N	0
\.


--
-- Data for Name: gz_bands; Type: TABLE DATA; Schema: public; Owner: gigzito
--

COPY public.gz_bands (id, name, slug, bio, genre, avatar_url, banner_url, city, state, website_url, instagram_url, tiktok_url, youtube_url, live_stream_url, is_live, created_by, created_at, band_type, allow_guest_posts) FROM stdin;
1	Commit UI	commit-ui	we are an AI band	Rock	/uploads/1776351665725-052adcd188b5b462.jpg		Glendale						\N	f	9	2026-04-16 03:16:47.556159	band	f
\.


--
-- Data for Name: gz_flash_ads; Type: TABLE DATA; Schema: public; Owner: gigzito
--

COPY public.gz_flash_ads (id, user_id, title, artwork_url, retail_price_cents, discount_percent, quantity, claimed_count, duration_minutes, potency_score, status, expires_at, created_at, display_mode, admin_note, coupon_code, coupon_expiry_hours) FROM stdin;
5	9	test2 a great ad	\N	6400	77	100	0	1500	0	expired	2026-04-14 02:22:46.269	2026-04-13 01:22:46.269851	countdown	\N	\N	48
4	9	this is a test 1	/uploads/1776042920946-721a1aa6e8d3.png	11600	45	100	0	1440	0	expired	2026-04-14 01:15:56.629	2026-04-13 01:15:56.630193	countdown	\N	\N	48
6	9	Test#3	\N	80000	56	100	2	6000	20.720797	active	2026-04-18 15:53:46.393	2026-04-14 11:53:46.394799	countdown	\N	\N	48
2	7	Ad #2 - You Can't Miss it!	/uploads/1773884245762-c8f3683b66d2.jpg	1500	87	100	0	1440	0	expired	2026-03-20 01:38:00.739	2026-03-19 01:38:00.740089	countdown	\N	\N	48
1	7	Summer Test Sale!!!	/uploads/1773882067687-5fbbd2eb4cf6.png	9999	78	10	1	1440	0	expired	2026-03-20 01:01:44.845	2026-03-19 01:01:44.847707	countdown	\N	\N	48
7	7	test20	\N	4900	90	10	0	72	0	expired	2026-04-15 16:17:57.864	2026-04-15 15:05:57.864879	countdown	\N	\N	48
3	7	Ad #3 Have to Sell Today!	/uploads/1773884854644-5ffb2e5765a5.png	11400	25	10	0	1440	0	expired	2026-03-20 01:50:47.874	2026-03-19 01:50:47.876003	countdown	\N	\N	48
\.


--
-- Data for Name: gz_flash_claims; Type: TABLE DATA; Schema: public; Owner: gigzito
--

COPY public.gz_flash_claims (id, flash_ad_id, email, coupon_code, claimed_at) FROM stdin;
1	6	brandonspower@gmail.com	\N	2026-04-17 02:31:40.693835
\.


--
-- Data for Name: gz_music_comments; Type: TABLE DATA; Schema: public; Owner: gigzito
--

COPY public.gz_music_comments (id, track_id, user_id, content, created_at) FROM stdin;
\.


--
-- Data for Name: gz_music_likes; Type: TABLE DATA; Schema: public; Owner: gigzito
--

COPY public.gz_music_likes (id, track_id, user_id, created_at) FROM stdin;
4	16	9	2026-04-16 14:15:28.909815
5	15	9	2026-04-16 14:15:38.207635
6	14	9	2026-04-16 21:42:14.882105
\.


--
-- Data for Name: gz_music_ratings; Type: TABLE DATA; Schema: public; Owner: gigzito
--

COPY public.gz_music_ratings (id, track_id, user_id, stars, created_at) FROM stdin;
11	16	9	6	2026-04-16 14:15:18.699049
12	15	9	6	2026-04-16 14:15:39.470684
13	14	9	6	2026-04-16 21:41:35.142331
14	13	9	6	2026-04-16 21:41:58.558794
\.


--
-- Data for Name: gz_music_tracks; Type: TABLE DATA; Schema: public; Owner: gigzito
--

COPY public.gz_music_tracks (id, title, artist, genre, cover_url, audio_url, file_url, license_file_url, download_enabled, authenticity_confirmed, uploader_user_id, submitted_by, like_count, status, created_at, play_count, shared_to_library, band_id) FROM stdin;
16	Now Ear Dis (Kingston Remix)	Skullabore	Reggae	/uploads/gz-music/1776348214886-6186ebfad85ea6a6.png	\N	/uploads/gz-music/1776348214877-7731b33662d0e48a.mp3	\N	t	t	9	9	1	active	2026-04-16 14:03:34.907322	2	t	\N
15	Now Ear Dis	Skullabore	Reggae	/uploads/gz-music/1776348047646-5768e2a4d33afb58.png	\N	/uploads/gz-music/1776348047637-1c37c1c1f4c2d5ac.mp3	\N	t	t	9	9	1	active	2026-04-16 14:00:47.672877	2	t	\N
13	Glazed	Commit UI	Grunge	/uploads/gz-music/1776292482320-688f0c070ec74dbc.jpg	\N	/uploads/gz-music/1776292482304-00424ca46d770f2d.mp3	\N	t	t	9	9	0	active	2026-04-15 22:34:42.322704	3	t	1
14	Keep It Moving (KIM)	Commit UI	Rock	/uploads/gz-music/1776347561945-45f215e9396f82b5.jpg	\N	/uploads/gz-music/1776347561929-34c143a831aed9b0.mp3	\N	t	t	9	9	1	active	2026-04-16 13:52:41.950482	2	t	1
\.


--
-- Data for Name: injected_feeds; Type: TABLE DATA; Schema: public; Owner: gigzito
--

COPY public.injected_feeds (id, platform, source_url, display_title, category, inject_mode, status, starts_at, ends_at, created_by, created_at, updated_at) FROM stdin;
1	YouTube	https://www.youtube.com/live/xf9Ejt4OmWQ?si=Uisqap-NiObIHCod	Admin Live Feed	\N	immediate	active	\N	\N	7	2026-03-10 03:15:42.797035	2026-03-10 03:15:42.797035
2	YouTube	https://www.youtube.com/live/xf9Ejt4OmWQ?si=Uisqap-NiObIHCod	Admin Live Feed	\N	immediate	active	\N	\N	7	2026-03-10 03:15:52.886999	2026-03-10 03:15:52.886999
3	YouTube	https://www.youtube.com/live/34H1XIjnfKM?si=HTEyTjB3-mXj3Xe6	Admin Live Feed	\N	immediate	active	\N	\N	7	2026-03-10 03:16:36.574402	2026-03-10 03:16:36.574402
4	YouTube	https://www.youtube.com/live/Cwq3AFyV044?si=Y0Sm_k7bbuZAbbrq	Admin Live Feed	\N	immediate	active	\N	\N	7	2026-03-10 04:09:25.263979	2026-03-10 04:09:25.263979
5	YouTube	https://www.youtube.com/live/Cwq3AFyV044?si=Y0Sm_k7bbuZAbbrq	Admin Live Feed	\N	immediate	active	\N	\N	7	2026-03-10 04:18:03.991582	2026-03-10 04:18:03.991582
6	YouTube	https://www.youtube.com/live/ecxVwudCL1Y?si=XmQ_3ZzS_Fwniuaq	Admin Live Feed	\N	immediate	active	\N	\N	7	2026-03-10 04:19:47.585969	2026-03-10 04:19:47.585969
7	YouTube	https://www.youtube.com/watch?v=ecxVwudCL1Y	Admin Live Feed	\N	immediate	active	\N	\N	7	2026-03-10 04:25:28.752692	2026-03-10 04:25:28.752692
8	YouTube	https://www.youtube.com/watch?v=ecxVwudCL1Y	Admin Live Feed	\N	immediate	active	\N	\N	7	2026-03-10 04:26:18.375039	2026-03-10 04:26:18.375039
9	YouTube	https://www.youtube.com/watch?v=ecxVwudCL1Y	Admin Live Feed	\N	immediate	active	\N	\N	7	2026-03-10 04:30:05.298909	2026-03-10 04:30:05.298909
10	YouTube	https://www.youtube.com/watch?v=ecxVwudCL1Y	Admin Live Feed	\N	immediate	active	\N	\N	7	2026-03-10 04:30:31.725565	2026-03-10 04:30:31.725565
11	YouTube	https://www.youtube.com/watch?v=KE1k_yGke2E	Admin Live Feed	\N	immediate	active	\N	\N	7	2026-03-10 04:31:30.145419	2026-03-10 04:31:30.145419
12	YouTube	https://www.youtube.com/live/H5cWx-bR4tM?si=WhGVoQc4t1fWBgaZ	Admin Live Feed	\N	immediate	active	\N	\N	7	2026-03-10 14:02:35.474263	2026-03-10 14:02:35.474263
13	YouTube	https://youtu.be/2uUZWqneppU?si=YhjzWJVU9i2VnC-O	AURUM CEO Call	Crypto	immediate	active	\N	\N	7	2026-03-16 13:34:45.314022	2026-03-16 13:34:45.314022
14	YouTube	https://youtu.be/2L8_DF1xyVw?si=lfeZvn1WEjJmMBbN	Aurum Presentation - 	crypto	fallback	active	\N	\N	7	2026-03-16 13:39:53.981122	2026-03-16 13:39:53.981122
\.


--
-- Data for Name: leads; Type: TABLE DATA; Schema: public; Owner: gigzito
--

COPY public.leads (id, video_id, creator_user_id, first_name, email, phone, message, video_title, category, created_at, viewer_username, viewer_city, viewer_state, viewer_country) FROM stdin;
1	19	7	brandon	brandonspower@gmail.com	\N	\N	How to Manifest...Stop That Emotion	MARKETING	2026-03-15 22:01:46.681954	admin	\N	\N	\N
3	21	13	Admin	admin@gigzito.com	\N	\N	Western Wear Try on Haul! 	INFLUENCER	2026-03-21 01:17:32.490104	admin	Frankfurt am Main	Hesse	Germany
\.


--
-- Data for Name: listing_comments; Type: TABLE DATA; Schema: public; Owner: gigzito
--

COPY public.listing_comments (id, listing_id, author_user_id, author_name, comment_text, is_clean, created_at, is_read, viewer_username, viewer_email, viewer_city, viewer_state, viewer_country) FROM stdin;
1	19	9	Josh	this is great	t	2026-03-15 04:01:05.669377	t	\N	\N	\N	\N	\N
2	19	7	Admin	this is an awesome video!	t	2026-03-18 01:51:43.195016	f	admin	\N	Frankfurt am Main	Hesse	Germany
3	20	7	Admin	hey homie!	t	2026-03-18 02:33:15.493284	t	admin	\N	Frankfurt am Main	Hesse	Germany
\.


--
-- Data for Name: live_sessions; Type: TABLE DATA; Schema: public; Owner: gigzito
--

COPY public.live_sessions (id, creator_user_id, provider_id, title, category, mode, platform, stream_url, thumbnail_url, viewer_count, tier_minutes, tier_price_cents, status, started_at, ended_at) FROM stdin;
\.


--
-- Data for Name: love_votes; Type: TABLE DATA; Schema: public; Owner: gigzito
--

COPY public.love_votes (id, voter_user_id, provider_id, month_key, created_at) FROM stdin;
1	11	7	2026-03	2026-03-11 01:41:01.206301
2	9	13	2026-03	2026-03-18 01:20:04.080688
3	9	19	2026-04	2026-04-14 13:35:47.388958
\.


--
-- Data for Name: marketer_audiences; Type: TABLE DATA; Schema: public; Owner: gigzito
--

COPY public.marketer_audiences (id, provider_user_id, lead_name, lead_email, lead_phone, source_listing_id, created_at) FROM stdin;
1	7	brandon	brandonspower@gmail.com	\N	19	2026-03-15 22:01:46.684597
2	13	Admin	admin@gigzito.com	\N	21	2026-03-21 01:17:32.494712
3	9	brandonspower	brandonspower@gmail.com	\N	\N	2026-04-17 02:31:40.695783
\.


--
-- Data for Name: mfa_codes; Type: TABLE DATA; Schema: public; Owner: gigzito
--

COPY public.mfa_codes (id, user_id, code, expires_at, used_at, resend_count, last_resend_at, created_at) FROM stdin;
261	7	589034	2026-04-15 14:04:12.869	2026-04-15 13:54:35.337	0	\N	2026-04-15 13:54:12.87136
232	23	385505	2026-04-13 04:20:30.266	2026-04-13 04:11:03.691	0	\N	2026-04-13 04:10:30.267524
9	11	727096	2026-03-11 01:43:51.852	2026-03-11 01:34:15.002	0	\N	2026-03-11 01:33:51.854494
13	12	963908	2026-03-11 23:41:09.485	2026-03-11 23:31:22.297	0	\N	2026-03-11 23:31:09.48737
272	9	245578	2026-04-16 17:42:50.827	2026-04-16 17:34:18.049	0	\N	2026-04-16 17:32:50.831026
186	16	745284	2026-04-09 23:57:37.955	2026-04-09 23:48:25.513	0	\N	2026-04-09 23:47:37.958441
102	18	961585	2026-03-19 19:40:59.109	2026-03-19 19:31:13.943	0	\N	2026-03-19 19:30:59.111206
158	19	579693	2026-03-22 17:31:17.66	2026-03-22 17:21:32.412	0	\N	2026-03-22 17:21:17.662438
274	27	183918	2026-04-16 19:34:22.254	2026-04-16 19:24:35.34	0	\N	2026-04-16 19:24:22.256328
244	24	814217	2026-04-14 16:04:53.218	2026-04-14 15:55:31.186	0	\N	2026-04-14 15:54:53.221171
52	15	641524	2026-03-16 22:14:06.137	2026-03-16 22:04:19.851	0	\N	2026-03-16 22:04:06.139309
246	26	404822	2026-04-14 17:13:07.037	2026-04-14 17:04:07.656	0	\N	2026-04-14 17:03:07.038805
249	25	994935	2026-04-14 19:51:17.784	2026-04-14 19:41:46.002	0	\N	2026-04-14 19:41:17.787928
30	14	196948	2026-03-14 07:00:02.761	2026-03-14 06:50:12.62	0	\N	2026-03-14 06:50:02.763076
56	17	264182	2026-03-17 02:10:00.283	2026-03-17 02:00:22.288	0	\N	2026-03-17 02:00:00.28625
169	8	879005	2026-03-22 23:38:05.526	2026-03-22 23:28:32.389	0	\N	2026-03-22 23:28:05.530012
59	13	707022	2026-03-18 00:40:03.873	2026-03-18 00:30:32.123	0	\N	2026-03-18 00:30:03.877118
170	20	721586	2026-03-27 16:36:22.263	2026-03-27 16:27:02.674	0	\N	2026-03-27 16:26:22.26583
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: gigzito
--

COPY public.notifications (id, user_id, type, title, message, link, is_read, created_at) FROM stdin;
\.


--
-- Data for Name: presenter_contacts; Type: TABLE DATA; Schema: public; Owner: gigzito
--

COPY public.presenter_contacts (id, presenter_user_id, member_user_id, opted_in_at, active, opted_out_at) FROM stdin;
\.


--
-- Data for Name: profile_wall_posts; Type: TABLE DATA; Schema: public; Owner: gigzito
--

COPY public.profile_wall_posts (id, profile_id, author_user_id, author_name, author_avatar, message, created_at) FROM stdin;
\.


--
-- Data for Name: provider_profiles; Type: TABLE DATA; Schema: public; Owner: gigzito
--

COPY public.provider_profiles (id, user_id, display_name, bio, avatar_url, thumb_url, contact_email, contact_phone, contact_telegram, website_url, username, primary_category, location, instagram_url, youtube_url, tiktok_url, facebook_url, discord_url, twitter_url, photo1_url, photo2_url, photo3_url, photo4_url, photo5_url, photo6_url, webhook_url, ad_format, show_phone) FROM stdin;
11	11	Jaren Tompkins	I'm someone who values hard work, curiosity, and constantly improving my future. I'm always looking for ways to turn knowledge and opportunities into real results while continuing to grow both personally and professionally 			\N	\N	\N	\N	jdtompkins22	MARKETING	Phoenix, AZ	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
12	12					\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
24	24	Love wins	stuff	/uploads/1776176633150-74916d7bc0a0.jpg		\N	\N	\N	\N	\N	RANDOMNESS	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N		f
14	14	Joshua	I.T			\N	\N	\N	\N	joshua	COURSES	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
25	25	Prosper with Angie	I am an Entrepreneur that loves helping others learn how to create passive income with crypto. AI Bot, Nodes, mining and more.  	/uploads/1776184576663-e8948f8cfbea.jpg		Shopwithangietoday@gmail.com	4802690107	CryptoAngie Only Account	https://t.me/CryptoAngie Only account	cryptoqueen	CRYPTO	Arizona	\N	\N	https://www.tiktok.com/@lifewithangietoday?_r=1&_t=ZT-95XKMIIiQdq	https://www.facebook.com/share/17rHJqvknY/	\N	\N	/uploads/1776184644803-393b07fe6390.png	/uploads/1776184721001-ac6aab4a8d12.png	/uploads/1776184795703-f70eb29c8bf0.png	\N	\N	\N	\N	VIDEO	t
26	26					\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
15	15	Nolan F	Individual's Journey in Life Integrating the Four Pillars of Personal Development. \nFaith - Family - Frequency - Flow	https://cdn.abacus.ai/images/01fd1346-ceec-4cd0-b0e9-86fc30a3fcda.png		nolanfierro@gmail.com	\N	\N	\N	liveleaf	COACHING	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
27	27					\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
8	8	Brandon717	A son of a Sun			brandon@gigzito.com	\N	\N	\N	\N	\N	Glendale, AZ	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
17	17	Instig8r	Just here for the party	/uploads/1773705075761-a5c7302e5bcd.jpg	/uploads/1773705098516-d50ef3ae8eb4.jpg	\N	\N	@ScorpioFlame	\N	instig8r	PRODUCTS	Nebraska	\N	\N	https://www.tiktok.com/@kimgames3001	\N	\N	\N	/uploads/1773705227914-a9d78c22c3dc.jpg	/uploads/1773705237931-2fceb1103f49.jpg	/uploads/1773706864438-1525fe57b472.jpg	/uploads/1773706884546-f5aa9c5169ff.jpg	\N	\N	\N		f
13	13	cely	PHX brand ambassador & promo model 🏜️🌞	/uploads/1773794124925-520d955f2cc7.png		cely@gigzito.com	4808599567	\N	\N	celypromo	INFLUENCER	Phoenix, AZ	https://instagram/@ccelycel	\N	https://www.tiktok.com/@celysvids	\N	\N	\N	/uploads/1773794231471-998fb65fa4c7.png	\N	\N	\N	\N	\N	\N	VIDEO	f
18	18					\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
19	19	Living free	I am a mindset mentor helping others renew and transform their minds	/uploads/1774200252232-1425988cb60f.jpeg		reachingcasry@gmail.com	\N	\N	\N	livingfree	COACHING	Florida	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N		f
20	20	Built-Income-&Growth	I love to create BIG opportunities for the “little guy”! The poor dream of wealth, the rich are given wealth… but the self-made BUILD it! Let’s build together!	/uploads/1774629706908-8ff39040523e.png		\N	\N	\N	\N	big_roy	BUSINESS	Beaumont, CA	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N		f
16	16	Susan	creator and visionary of this world 	/uploads/1775778802562-99fcf4ad1dde.jpeg	/uploads/1775778844427-9ea8e753a88e.jpeg	\N	\N	\N	https:susanfierroart.com	creation	PRODUCTS	Katonah, New York	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N		f
21	21					\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
22	22					\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
23	23					\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
9	9	Josh	I'm a super cool dude			josh@gigzito.com				joshie	INFLUENCER	Phoenix Arizona	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
7	7	Gigzito Admin	This is a perfect Test	https://i.pravatar.cc/150?img=1	https://picsum.photos/seed/alex/400/300	brandon@gigzito.com	\N	\N	\N	gzadmin	MARKETING	New York, USA	\N	\N	\N	\N	\N	\N	/uploads/1773601648452-76ab3ec99091.png	\N	\N	\N	\N	\N	\N	\N	f
\.


--
-- Data for Name: session; Type: TABLE DATA; Schema: public; Owner: gigzito
--

COPY public.session (sid, sess, expire) FROM stdin;
Oq4uCrOFu5VeFKeGwqVnNd8-zl_TGz4_	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T00:30:44.818Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 00:30:45
HIXLuvx1GWbJkZGDg7XTk4l401R7x3Kz	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T00:30:44.926Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 00:30:45
EvFUEH-WfWLB7AdGuGHSMVWFzfZNsto1	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T00:30:44.933Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 00:30:45
YsbvgXjxqdhmRg0-mio_osElN4G0fWQr	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T00:33:35.827Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 00:33:36
2otUpMW4C4gYEdwp7OfT6zeR_Ld6v078	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T00:33:35.843Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 00:33:36
raUi6SGs7dYReD1OrIv9fvVZ3lk334fF	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T00:33:35.915Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 00:33:36
SlRkkeWtu_wSiInZ2KU2AKCU8adeGh_Y	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T00:33:35.924Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 00:33:36
F8E3ucW_qKEWd4VbVtuYDHMRP6yG-ZGT	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T00:47:41.354Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 00:47:42
vLYuU2c-LO87rlOUeW8JhSSoUrbGDlid	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T00:47:41.376Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 00:47:42
AduSeL1B_vwG6LGCHVodrHQph3KcTuHm	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T00:47:41.468Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 00:47:42
xo9m0brpUaUTUiez5joP8kjPoE1H-4Wu	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-21T23:29:36.744Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":7,"role":"SUPER_ADMIN","subscriptionTier":"GZEnterprise"}	2026-04-21 23:29:37
LBLk6HFHSBbyrI_czdwlZm4mYHcA9AAT	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T00:47:41.480Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 00:47:42
pd_hgn7lfvoJ2lpaiwsbzPz1Yt5UcivZ	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T00:50:51.685Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 00:50:52
nuygx8s0i7IIY35NZwBarITd4hyGKrgR	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T01:27:54.474Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 01:27:55
mo9J4E1cW24hP6fHan_7wS7XPC2vRFv8	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T00:50:51.693Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 00:50:52
HYcyt60weB_C9JVqlTGtStZnc4UItCUE	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T00:50:51.791Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 00:50:52
tstJwzD6M8WU8oxbqRP9POK7zdVHAHLo	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T00:56:20.813Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 00:56:21
iuUOkOiW_ef69KbSSSq3YNzKRdXaNS2G	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T00:56:20.815Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 00:56:21
8UNw5jcg0fWKGvq2s0121s4PYmXXVRQs	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T00:59:50.159Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 00:59:51
vK6tiBdBBxwVW8Wd01WaHbIse89jRb8s	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T00:59:50.239Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 00:59:51
SEI1xTlz5j1HPhwN2c0vCpoCVMZYfcoL	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T00:59:50.279Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 00:59:51
DQ3cmmX2bVL7nuKV7lKi3_OTSUMkEaYb	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T00:59:50.291Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 00:59:51
tKoUuYGDY1SFuTtRi599l6fvOQw070mk	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T01:18:24.411Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 01:18:25
cVOVcBMKdk82l8fS2KREpWY-gACwU1VB	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T01:24:11.707Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 01:24:12
Q7KMCo2zvNLxr10TG0IlzBEKaqHFKGSo	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T01:24:11.834Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 01:24:12
7Z-lMC8P55b21wlP5njsgac5XNNPiV_W	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T01:24:11.844Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 01:24:12
KLUFrO7KIpoayKlFYpuHOq5Qv7eyN6y5	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T01:24:11.852Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 01:24:12
SHYD59swdN9FY4YqWjOqEn_QeOEskrLv	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T01:26:12.385Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 01:26:13
7JjNuvC6bnEm6ZuNPN1SoFZBYQz7Xj2j	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T00:30:44.940Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 00:30:45
dppqjoeEQ_wxJ7IcImNV_dVZNLs_QNSg	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T00:30:44.952Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 00:30:45
vu-_5AVZywWmz8Taqvd7Q6lUXbc7O6yQ	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T00:33:35.912Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 00:33:36
WX50ng_Ge871q2_2jOAnbmF0wxShrRv_	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T00:47:41.472Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 00:47:42
6biOMlkWBs5QLdj8gPgvqViTuIVQZPjb	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T00:50:51.684Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 00:50:52
XZHiBYhcDsFPdhPTlWeNZHHHFR3u-6J1	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T00:50:51.688Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 00:50:52
CynPjMIt5nyCKN7IA11GOQwVuhothyhz	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T00:56:20.673Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 00:56:21
JlDst2UyrHuLLtU2kT0c_w3M34wOODTE	{"cookie":{"originalMaxAge":2592000000,"expires":"2026-04-26T16:27:02.676Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":20,"role":"PROVIDER","subscriptionTier":"GZLurker"}	2026-05-03 07:02:31
fBKLx8Hclk8f5ib7Ga2F5aJkyrQ22GC6	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T00:56:20.805Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 00:56:21
d7CCLDaXfcldwoydQRahm94tfzxLpqhx	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T00:56:20.815Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 00:56:21
vvAN9AOWm3jt1HAM2MNUpaQcO5uwiroN	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T00:59:50.134Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 00:59:51
nMUn-CYv92xmODXg4mRd0KXP-hibBp8R	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T01:27:12.654Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 01:27:13
DvAB70xRYkHRLTQvPlxtfPkbY4A-6Y_4	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-21T17:52:52.064Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":7,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-21 17:52:53
9GaymEbRVNhThC4qLKuxbFOKaWA-bx8l	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T01:27:54.489Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 01:27:55
KNdLNnSqaCVXgrtjekyXy6166mpEY8H5	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T01:27:54.524Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 01:27:55
MLLpXOo8pkrkPP47XgMi7-dNQyvFbyBf	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T01:27:54.530Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 01:27:55
kURlR8Ak7aV7kZgPAubwnbpvwSG34qhq	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T01:27:54.578Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 01:27:55
Q1FF52KaTh0-jQqH6JZRYw_8XpnjQENJ	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T01:27:54.598Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 01:27:55
sd0VOCGJF5ROd1TzKEzJoeyCJgGYwkVz	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T01:22:46.271Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 01:22:47
3y3LlYy345ExBOSiJ3ynOnKJ9og14W3p	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T01:24:11.842Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 01:24:12
cNqs-kZ7yKAMYtUm-wa_92hdjsaXehLx	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T01:24:11.844Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 01:24:12
z_rjWeOv1HAZF8R7xP44AEWkiU2nadqx	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T01:28:54.845Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 01:28:55
P_NSCbtiQzVe13zuMhZE2PyFDKS7EWNe	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T01:25:12.119Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 01:25:13
RSg7U8XvLSm8l2Aj9nURKjCG_q-BqCCf	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T01:29:55.113Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 01:29:56
rH3uyUFoA1UxuaQXg5iLDTu-ryNxs5XK	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T01:30:21.809Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 01:30:22
D8uOZP-aQOAxw_NjG0rUGX04E7dqjYWV	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T01:30:21.810Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 01:30:22
YBtU-ZL6Lv-bX_Jb3fWM4JUouEuozupz	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T01:30:21.816Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 01:30:22
U8zyWY9aWd9_b3SdXAQqGTkR3x9F9mb2	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T01:30:21.816Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 01:30:22
9VVYlCF3DjYESRFXW0eRK7nF9_KNmj4_	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T01:30:21.820Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 01:30:22
N5i66S_uba1fYsgZabquSPYh61RLSnTo	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T01:30:27.467Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 01:30:28
Ny2IDljAi6OVwXJ2CYciLDHndCY9G10S	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T01:36:12.323Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 01:36:13
82iykY8Gr_XDx-xgCEuPtD4ZffI3RlRA	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T01:36:12.442Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 01:36:13
2Z5IubUFZqdbS7vATTrYfqIVehCGJFbp	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T01:36:12.451Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 01:36:13
7ZsfOaLXHcuLcbFAYHmtQRUb-QJbP56j	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T01:36:12.459Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 01:36:13
Aak_Re3XoGC0iLGkcJguzgjK_SS3st4s	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T01:36:12.469Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 01:36:13
Y1STBsmHCf6ibQkQzSFV-y6C0ryO6sn1	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T01:36:12.471Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 01:36:13
AAS5KyyYBpZjRepm6vdHZ1rj0FhvRlf8	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T01:37:12.734Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 01:37:13
BaHEkYRFva0zNUJwBXmWlcpirP9RR3x6	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T01:38:13.002Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 01:38:14
OEPcLoYz28sDu-XjlJmDag7-ulFFE45Z	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T01:39:13.318Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 01:39:14
L4yOdfhJ15-SDkO01MXUSwIdaqF363J1	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T02:37:20.397Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 02:37:21
IpNZshRzhcf6GoZL54YSJUcrIT7og-Hk	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T02:37:49.898Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 02:37:50
KEutWvxnSPZa1VIWBNypmm_V9tRoGmZY	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T02:37:49.908Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 02:37:50
1OWstpHscIkJ26RujCWAcFIjT3ops3Bx	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T02:37:49.911Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 02:37:50
IM9YQHnZipgdetsam_JOnPoE3reYFepD	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T02:37:49.918Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 02:37:50
axU8M3nyYu51M6Y9g6ETZoZyNrrXC8U3	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T02:37:49.922Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 02:37:50
VIOLS_16b1pKGtNsn9sR4_hKfyuXf5Ds	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T02:37:49.925Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 02:37:50
YxXeMLD3xJE-UTkIU6JgG1xwdpohvWUd	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T23:41:35.139Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 23:41:36
4SBh5MoopKedk7sWfdVZOylpTKKWR2pB	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-21T03:49:07.237Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-21 03:49:08
nO8VhZ8u74vLODw_I--_vBKuIN1PBMpo	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T23:41:35.274Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 23:41:36
Kji-kRchPxFxSRbUS1pkkDNAZ6_b47Xu	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T02:53:04.088Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 02:53:05
RYfwC8tOORwHQ9f2Q2Mh7y40dzFpzuLI	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T02:53:04.096Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 02:53:05
nVZk5biaoUYBk5jM7qT8TrGLV6PP5CXR	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T02:53:04.096Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 02:53:05
6n-ackVaU-O4ef4-Jd1ndQ636hldkcoV	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T02:53:04.103Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 02:53:05
oGEvGsfOXJITWE942K8qPiqFycvHfPVc	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T02:53:04.108Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 02:53:05
r6u3H7Z8RqBHtZ2YWjQ64qv8wQeiKF0h	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T02:53:04.109Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 02:53:05
TxvBQ7EgLLy2Apc2OSBqZXqRppZauS8O	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T02:54:04.403Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 02:54:05
Kh-v_w3rFD46SBNExzdGlisenLMiSWyR	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T02:55:04.685Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 02:55:05
8rDHTCPaKYIqwX7cKira-y8Rm7NLmYKx	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T02:56:04.965Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 02:56:05
8Q0ywlMF-qNGIhamLJPMSTtO3ZCdOyYp	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T02:57:05.232Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 02:57:06
0qHoDT_qIkPVcDVjEFNx7oIiKFt2pt5_	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T02:58:05.496Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 02:58:06
fkiPCYNfhr_XGJuvpmM-0948xAmtRvvn	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T02:59:05.750Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 02:59:06
1CVfo19B7YIcqTN4A0phhryIhkvg5At1	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T03:00:06.010Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 03:00:07
RRQ1b8PkL9cXWdjkwJfQJzKOThwnA-Y6	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T03:16:30.463Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 03:16:31
_0oy0m23k6mfmwIjj3cJbzOxvh3KIOTo	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T03:16:30.575Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 03:16:31
I4VuvywFyVsmPSFMN6uZ9la__UJsbDUn	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T03:16:30.588Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 03:16:31
_XUZJj_yWLwJsy1w6JVCS836uq-EDP3i	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T03:16:30.595Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 03:16:31
lBfITppqW-Q9K3FksBI7QPSgh8TedwY7	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T03:16:30.599Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 03:16:31
uGgbKABE2CG4AyDMNRv3boP4g6DLbYPB	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T03:16:30.600Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 03:16:31
P-gKxcxrAoFU4fw_85Qwk3OwfD5i5r4h	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T03:16:50.493Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 03:16:51
y3ZxMVSK-tXreTqN1mzSxlQvpMt7Y0qL	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T03:17:30.868Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 03:17:31
xienXK00_vHwr7RDBW0evLsk9tcBHK0m	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T03:18:31.140Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 03:18:32
fV3cLiuTDCSQVYIHXyoiO8yCa260umHw	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T03:19:31.571Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 03:19:32
Va8yDlCrj4f8nhml2JEBMgAQKPreEbzi	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T03:20:31.860Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 03:20:32
AOKb_EMKAylsO_v81VjWqgB9ZA5CpkSM	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T03:21:32.155Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 03:21:33
wYRko7M8BQ8gIBCFPD2wnQvjAs3q8Cdj	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T03:22:32.426Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 03:22:33
6YUQ8YpiSTqQg6ZnpQHcB1ED28RTS7e1	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T03:22:50.829Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 03:22:51
X5FnypI1xphpEsR9tZyFvsPg4AWNWgs0	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T03:34:05.977Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 03:34:06
c10X_itz20WGOAX3OzqTrEWLI0YDKt35	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T03:34:06.079Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 03:34:07
jCS7KvO-mg1wVy1fq9SXJ7C0nEQt4qSy	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T03:34:06.089Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 03:34:07
Jryh0IsbKLmv4q6MhwmKq_GMA5WCKxV5	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T03:34:06.101Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 03:34:07
rzUjGhSN5UYZfcrpAJz32f_IoAaNTvwf	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T03:34:06.106Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 03:34:07
KixKp4yEqCGqz7v9dyfZq35b07Z4PR-O	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T03:34:06.113Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 03:34:07
hkUA2fjGsDWq-Qw_aFM6GW5HzRzCVFqi	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T03:34:15.493Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 03:34:16
cc1GZQJiRZp6Rmr9L44-6uy1IX9J9ttI	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T03:35:06.384Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 03:35:07
Ev1pTGOIpDfHMslVdwBF93JGahEu1sMT	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T03:35:51.898Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 03:35:52
JxfweH7UlvTH_PxMuuKTlh8drLOyAYtW	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T03:36:06.662Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 03:36:07
Hp5VxxvK2HCqsixbjeg2jtpj_jJl2oMd	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T03:37:06.933Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 03:37:07
4qoAADEheD4iEIw0_2qXjVM_YHMo0Aui	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T03:38:07.361Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 03:38:08
CV-8PNsb5QHBdx5MJeJQYfqK3Bdzw7HW	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T03:39:07.671Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 03:39:08
lSFe-A684n3Oecp-GIVNQi9YNlvgEoAF	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T03:40:07.952Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 03:40:08
LGs5FTiFgy3HY0z9xSB7IAEQtLZgWAtE	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T03:41:08.222Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 03:41:09
XGaTtN-CWIQEjL9KqayxVXVBsjsAOwbn	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T03:42:08.495Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 03:42:09
2reW3C8lHZdUs3TGRrNyIXE5eZEPXCnC	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T03:46:24.129Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 03:46:25
TKZRtNO9_ZRzKyOZqTnCQFb7hybAU1UC	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T03:46:24.136Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 03:46:25
_DIjq8yxc_ce5fiJUbQiEWndDxV_LqLL	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T03:46:24.142Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 03:46:25
vrH-uEvJJSGwom7BHeNP5i6CmrQySpsu	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T03:46:24.144Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 03:46:25
2swdrMG-m9W2Iti1MFa-AtBMY0wciFMu	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T03:46:24.150Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 03:46:25
huN8ANw9NK_LPomH0vkVgV0GYqm1W3P-	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T03:46:24.152Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 03:46:25
CtlPoliCW9ojV725sOdvRKAXNHynYKIh	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T03:47:24.427Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 03:47:25
yON0IPpgSfOnaXGvqYjMmweOwTdgYEw7	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T03:48:24.703Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 03:48:25
qz35X7HC_lBhpSBuefQlgWsoWT86CxHV	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T03:49:24.996Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 03:49:25
dDosCaWhG2twmGgOXPzzwOwkK3s1i-ha	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T03:50:25.278Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 03:50:26
QVEo40VxCOs4l5FIcUA62wOLGm0ppaBe	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T03:51:07.702Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 03:51:08
9VKMvb_ixv6CJJ0gDYlq2a5ltKPJAZSD	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T03:51:25.662Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 03:51:26
Map22YfCla-j3mJuwLx_Lk6Gtk0DfYr7	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-21T15:58:35.685Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":24,"role":"PROVIDER","subscriptionTier":"GZLurker"}	2026-04-21 15:59:49
ModZbgIxhhZeOsPRjD_ijjylpwYGAlLG	{"cookie":{"originalMaxAge":2592000000,"expires":"2026-05-14T17:04:07.660Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":26,"role":"PROVIDER","subscriptionTier":"GZLurker"}	2026-05-14 23:22:00
HparCuJrFFHTf14FFKg_DBoDigllXNLl	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-21T23:32:59.330Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":7,"role":"SUPER_ADMIN","subscriptionTier":"GZEnterprise"}	2026-04-21 23:33:00
yYS387vSiEMlY_BlqeaLu0VWiHBTqYXK	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-21T23:40:46.866Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":7,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-21 23:41:27
2tqJEwnwNMpkLX2ZnVRcaBtSUPTgka1g	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T23:41:35.188Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 23:41:36
tRCczsbB-4hIR9cktHj3H0EPFTiKpqbp	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-21T03:49:07.289Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-21 03:49:08
Fw3loyE3JMrsJfkkdrLloCZdTApxkiFg	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-20T23:41:35.143Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-20 23:41:36
P7zbxB0xHdBbMSDrTG-tYu3pOkXtxJ5T	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-21T17:52:52.206Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":7,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-21 17:52:53
WxtOsYgNqAGTPyQxyGhuTuj8Mf23hkzO	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-21T03:49:07.249Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-21 03:49:08
cCwFtETp0va0w0wrtEEGkoGVG_Zevwm7	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-21T03:49:07.361Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-21 03:49:08
Vd7Jq8PzJQoV5IRaXBJLbHwLhKGUceIT	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-22T00:21:34.838Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":7,"role":"SUPER_ADMIN","subscriptionTier":"GZEnterprise"}	2026-04-22 11:53:32
cruS3FYNEKtOvm-m5fYAs3_dZUfSDXnG	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-22T13:44:37.756Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":7,"role":"SUPER_ADMIN","subscriptionTier":"GZEnterprise"}	2026-04-22 23:13:42
APdMm79f4RlUw8q_XKCNS_8zvh9ON6-U	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-23T00:43:33.070Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-23 00:43:34
n-CEppR8gJ08Vlaxh4Dy8YQ4dDa9WMT1	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-23T00:43:33.068Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-23 00:43:34
htWPlsxzYT85tY8I75i4b-Uivvtnbzvm	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-21T03:49:07.364Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-21 14:01:45
jQhbGRKAIHAoo0CsiSpgPawu96s4SE4B	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-23T13:42:26.403Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-23 15:56:39
f4UPVMEsfpKrBVD5w3QtLFm5NaZH1Cq6	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-23T00:43:33.073Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-23 00:43:34
47GKg6NZI2pO6u1oVdhVeL1AwJJaFCRA	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-21T23:40:46.554Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":7,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-21 23:41:27
DsQIBP1w29Usi_mButy6YDfU0QkpueEF	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-23T00:43:33.107Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-23 00:43:34
O81tuIDRxgJ7MSiKeBfVHZHYGG_ylJ5o	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-21T17:52:52.491Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":7,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-21 23:19:51
t0_1mMXSockNTBbZFABxwKADVhdHaDYr	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-21T23:40:46.502Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":7,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-21 23:40:47
sX_idS1qcJHq7Oh4BpJlkSj_poMVUUF6	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-21T17:52:52.052Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":7,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-21 17:52:53
ZoMxDDhfknaoJIi8GmT-JjGMMjMt4b0D	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-21T17:52:52.474Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":7,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-21 17:52:53
lGzgaj1dyzJurguWeJKMS7vKuJPjeQ0y	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-23T19:24:35.343Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":27,"role":"PROVIDER","subscriptionTier":"GZMarketerPro"}	2026-04-23 19:36:52
-2_Pyy2V_uKghJWDAOHRYkpD-Z_7IQep	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-23T03:10:47.221Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-23 12:40:10
erzkedmjLoKU03UzYoUZzG0iEBm-jLdC	{"cookie":{"originalMaxAge":2592000000,"expires":"2026-05-14T14:20:44.112Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":24,"role":"PROVIDER","subscriptionTier":"GZLurker"}	2026-05-14 15:53:37
Fjqwv31Cbiky3PuaO5X1JjfVovbZN-mv	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-23T00:43:33.193Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-23 03:05:01
OX5Pr0RdR9CcilN6g8Xz--3BXMXcaM9b	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-23T17:34:18.568Z","secure":true,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":9,"role":"SUPER_ADMIN","subscriptionTier":"GZBusiness"}	2026-04-24 01:15:35
\.


--
-- Data for Name: sponsor_ads; Type: TABLE DATA; Schema: public; Owner: gigzito
--

COPY public.sponsor_ads (id, title, body, image_url, target_url, cta, active, created_at, updated_at, sort_order, created_by, cta_mode, contact_username, contact_email, contact_message, ad_format, video_url) FROM stdin;
1	AI Bot Trading Continually Performs	Let an advanced AI trade for you 24/7. Set it up once and let it work around the clock.	/ads/aurum4.png	https://aiwealthsecret.io/?ref_code=ERUEUE&disable_popups=true	Learn More	t	2026-03-12 15:00:30.962647	2026-03-12 15:15:05.831577	0	\N	url	\N	\N	\N	TEXT	\N
8	Marketing Pro Wanted!	Earn 25% Monthly Commissions! 	/ads/ad-1773604060485-f5781e50.png	https://AiWealthSecret.io/?ref_code=Y20R0D&disable_popups=true	Learn More	t	2026-03-15 19:50:03.307401	2026-03-15 19:59:56.409	0	7	profile	admin	admin@gigzito.com		TEXT	\N
2	Introducing Aurum EX-AI Trading BOT	How I make daily profits from an AI trading robot who compounds my daily gains. 	/ads/ad-1773663813525-70491263.png	https://aiwealthsecret.io/?ref_code=ERUEUE&disable_popups=true	Learn More	t	2026-03-13 01:25:12.609391	2026-03-16 12:24:22.524	1	7	profile	admin	admin@gigzito.com		TEXT	\N
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: gigzito
--

COPY public.users (id, email, password, role, status, disclaimer_accepted, created_at, deleted_at, email_verified, email_verification_token, email_verification_expires_at, password_reset_token, password_reset_expires_at, subscription_tier, groups_enabled) FROM stdin;
11	jdaniel41200@gmail.com	8eb89eb49d303f624443baf572376fe041aa43b04ae0a70fbbe2b1a5c21e0cef658a2d2833c901ad0acaf59accdc12705c329b22df346ea791cff3a449a4a158.a8fbfa315484921a912df0dad86d84d3	PROVIDER	active	t	2026-03-11 01:29:48.776706	\N	t	\N	\N	\N	\N	GZLurker	f
12	gjwalsh91@gmail.com	83aacea8fce7e841b624cd3f91373af7b078f94019bf22411a356b7046f60a55dda0d711f94bb2b07e6614325384c566debc7d5fe4272c425e8f277aed56e471.6656fdf523d3c611d8aa5ebba83d0bd1	PROVIDER	active	t	2026-03-11 23:28:40.596337	\N	t	\N	\N	\N	\N	GZLurker	f
17	kim.javins@gmail.com	0bf4b763b17df38989baa4a568e1a6f26412c870e292d5255c90ab247100bc33175ab910f42e1ffff7049546aa653f383d9f5da07d870a991f0c2d1bd3b3397e.9c9a89ad724c9c9cf90dc383398610ea	PROVIDER	active	t	2026-03-16 23:43:54.556496	\N	t	\N	\N	\N	\N	GZMarketerPro	f
13	cely@gigzito.com	8e27ddfe90fd53a5d95dbdb0216071977128c2d616f4e45b9e08f60f328107b26b21a3a01e80b2d0ca88b624af84728301cd5db8e96af712de96bdb25b19dc92.1574624386b5486135e12075a0135287	PROVIDER	active	t	2026-03-13 01:28:19.467349	\N	t	\N	\N	\N	\N	GZMarketerPro	f
20	roytompkins22@gmail.com	8fb1c87532f341c9c86c7ccf6e11df65fe18edf0cef55664330a0e75d774f189c887d24dcfca47a6a04bbf20b7b8ccf56ff25bec7a13846cf72e3cd4cdc65ef3.4311dfbf831d0a02887d190b2e4e2f43	PROVIDER	active	t	2026-03-27 16:25:27.353204	\N	t	\N	\N	\N	\N	GZBusiness	f
14	josh.leal455@gmail.com	23bc4248819d55b2974f74102085aa1e65e6ad3c1bc66bf47c99a0f8dd24d8de083928dc789fa09b43d157c2c6f1baefe06a598ff4c17f920e95840eb76403c0.4be299c8ed1fe1d12af6a83c7373ed9c	PROVIDER	active	t	2026-03-14 06:49:39.564026	\N	t	\N	\N	\N	\N	GZBusiness	f
18	bluejbird11@gmail.com	e60c4e219dd90c00743a17f3eb271792b4f3bbdcb582386d2009c4dd232718dfbde84bbda11b3e3d5da69c54cee3194a13c969c751cd346da26d42dfadf8751f.ef429a7bbf74c25f7190443826998e12	INFLUENCER	active	t	2026-03-19 18:50:52.663538	\N	t	\N	\N	\N	\N	GZMarketerPro	f
16	susanfierro@me.com	fe1b418eebc1fa6a72b32006c2ef4ba69fe25f1a692b0b825144a81998f610332988f0c3351ff7697d0d107074c463f821d56bf39cc79f76492b45989800919f.956faff3bedde3342d1ea9f0910c0cfe	PROVIDER	active	t	2026-03-15 17:32:20.633316	\N	t	\N	\N	\N	\N	GZMarketerPro	f
19	reachingcasey@gmail.com	75b7cfe767a21565a57230bf88da4490520c0541aa8a76b735dd9f5b0abf7d5f3a99bb8cfb186abf69762222bd874f4ae44ce240f6beadaadc6d677b01c6fd5d.2a4fccaa7b0ac326b3f0558ef128221a	PROVIDER	active	t	2026-03-22 15:52:12.708429	\N	t	\N	\N	\N	\N	GZMarketerPro	f
15	nolanfierro@gmail.com	d57d5267e46a31376c776e975ce113d30e1efcab47d59168e18d7a93d9233ede5146b4f9971bb11d6957e242b65a84fefcf70322fb8acbf8ce99575a50bef141.2373018ade74776c345dc20f10845400	PROVIDER	active	t	2026-03-14 21:05:32.560688	\N	t	\N	\N	\N	\N	GZMarketerPro	f
9	josh@gigzito.com	891da23aedada69a4f76a01b39ad4856283f03cf52ecebdec22dc2a20d7f14a619db77c076bbaaaa88257ea9b1de0cd3cb8c9aac45d252073bf0d765595ff2fc.68481ae54b692126ecbbe2b75724716b	SUPER_ADMIN	active	t	2026-03-10 21:54:43.590328	\N	t	\N	\N	\N	\N	GZBusiness	f
8	brandon@gigzito.com	b105d925a1fe91ae47a292c6e487ad1c4b3ca5960e0ce955ef2b33063a1b5eea446aa2cff8f4abbd6a76ba682e6b5eefa5fd385e52e5d846f7501a93fe24ecc2.9db64a4edd58d6ed84a5122daeb87ed3	SUPER_ADMIN	active	t	2026-03-10 13:26:49.568614	\N	t	\N	\N	\N	\N	GZLurker	f
25	Shopwithangietoday@gmail.com	90dae08e586a60e8dd9280a4f0dde75487f72536d5d57f2489b904d3dccd19f4ae863eee94ef0bbce9ab2f815c0cb9055c428b2d378f80b73b63bf674f4a7bb4.f4bbdd82f0c0afe70b8bb25c0c5a9428	PROVIDER	active	t	2026-04-14 16:28:00.68043	\N	t	\N	\N	\N	\N	GZLurker	f
21	tester@gigzito.com	d7ea938ff43b88c1667461a3c01abbfdb73bf8380c5aae10083a9abe088f755878fd4a5f5dfe24996627b957191414e58ee2297622c7bf6a302355b84aecbf46.50f6f0aba2ff7ed634e0eae8136cad5f	PROVIDER	active	t	2026-04-10 22:18:06.504099	\N	f	b638a676cf0ba9f27e67402f0c76ec78680723e4e3c4d5048b8fd6438137783b	2026-04-11 22:18:06.431	\N	\N	GZLurker	f
22	testuser12345@example.com	84123f57715969cb6e6e4828ead0f4948302dff9ac349f7b391ac43f348d8327747a2caf0bbfc4498fca3ece3bcc0f38662548042d3afbd8aedd54a8c7bbe20e.f2ac2a65f2f7a744ccc7505e81157426	PROVIDER	active	t	2026-04-13 04:06:09.283486	\N	f	d13714642c48670e928e5ca5a44858f57d7f31b81785f8e29fa009501aa0c1a5	2026-04-14 04:06:09.214	\N	\N	GZLurker	f
23	juanito@gigzito.com	68cdcc658011d54e925b5ae0a941ebb5f089a435e7f7b01e64fed7750c9b33721d07f7ba0651e793cfd7c3e64d1033a662941097b7edb2d369a26b5ac1fb7d93.d2610a0347ca77489d40bd9ef95cab55	PROVIDER	active	t	2026-04-13 04:09:04.26903	\N	t	\N	\N	\N	\N	GZLurker	f
26	michael_barnes2005@yahoo.com	850c01e47d358c0fd9819c93182b63de131e176dcef7a1e56a7bbc35f6db39c7653ad859de4eec6dc1fa7f298708e14d533d68df4af015c89f1ca850fbf24496.981e63b78348e12fbb378d9b22e50a86	PROVIDER	active	t	2026-04-14 16:56:45.315857	\N	t	\N	\N	\N	\N	GZLurker	f
7	admin@gigzito.com	5266b28f85a9d4961fd4e73f25fe579ea3d30555a98793c782e4d19394d947ac472d992b712caaffd924daea4fca7bcbdb56bb5a91e716b61c0cbde1e5faf06e.2d5411d5ca759cf5f82217cea760f836	SUPER_ADMIN	active	f	2026-03-10 02:58:26.140934	\N	t	\N	\N	\N	\N	GZEnterprise	f
24	sharky290@gmail.com	e97c09716c1ba48f7773aa14b7163679600e139b3d594760fc604c9a6c340169e2bb0829af530956625ad2152539da2a36913332983d8b11b2d816fe01f2ef6d.46a32dd9defece0ab1934ec4a7516a68	PROVIDER	active	t	2026-04-14 14:01:11.644163	\N	t	\N	\N	\N	\N	GZLurker	f
27	laurent.lieben@gmail.com	81984b28509eb127fa6a2e4ff49b2b81b9450fe9b51e4595e5c266f79abfc2897ffc2db034a04c665e03177cd4c66aba2d215205e6dd6f4a491e2c447fddd3cd.09b3631cfd2fb7aaa5c021735ac37fdc	PROVIDER	active	t	2026-04-16 18:47:57.354742	\N	t	\N	\N	\N	\N	GZMarketerPro	f
\.


--
-- Data for Name: video_likes; Type: TABLE DATA; Schema: public; Owner: gigzito
--

COPY public.video_likes (id, video_id, user_id, created_at) FROM stdin;
3	21	9	2026-03-18 01:19:52.735875
19	21	7	2026-04-15 11:49:21.413716
20	31	7	2026-04-15 15:04:38.245267
21	31	9	2026-04-16 15:46:28.608979
\.


--
-- Data for Name: video_listings; Type: TABLE DATA; Schema: public; Owner: gigzito
--

COPY public.video_listings (id, provider_id, vertical, title, video_url, duration_seconds, description, tags, cta_label, cta_url, cta_type, flash_sale_ends_at, coupon_code, product_price, product_purchase_url, product_stock, status, drop_date, price_paid_cents, stripe_session_id, triaged_at, triaged_by, triaged_reason, like_count, reveal_url, reveal_email, reveal_name, collect_email, created_at, updated_at, scan_status, scan_note, post_type, bg_music_track_id, bg_music_volume, custom_vertical) FROM stdin;
19	7	MARKETING	How to Manifest...Stop That Emotion	https://youtu.be/bPCSq0xupJQ?si=at_fo4chHk6gOsIv	20	Neville Goddard is an inspirational teacher. Listen as he highlights the profound significance of pursuing inner fulfillment and authenticity rather than seeking external validation. \n\nNeville's philosophy provides transformative strategies that can help you cultivate self-assurance and achieve inner peace. By focusing on the power of imagination and the subconscious mind. \n\nNeville encourages a mindset of self-reliance and personal empowerment. \n\nSo, embracing his principles will lead you to genuine happiness, deep-seated confidence, and lasting success in both personal and professional realms.	{marketing,LOA,Abundance}	\N	\N	\N	\N	\N	\N	\N	\N	ACTIVE	2026-03-10	300	\N	\N	\N	\N	0	t	f	f	t	2026-03-10 03:07:53.548939	2026-03-10 03:07:53.548939	CLEAN	\N	VIDEO	\N	70	\N
20	13	INFLUENCER	*Try on Haul*	https://www.tiktok.com/@celysvids/video/7448425888233884974?lang=en	60	\N	{}	\N	\N	\N	\N	\N	\N	\N	\N	ACTIVE	2026-03-18	300	\N	\N	\N	\N	0	t	f	f	t	2026-03-18 00:45:30.161237	2026-03-18 00:45:30.161237	CLEAN	\N	VIDEO	\N	70	\N
21	13	INFLUENCER	Western Wear Try on Haul! 	https://www.instagram.com/p/DP0HV7xESVp/	60	\N	{}	\N	\N	\N	\N	\N	\N	\N	\N	ACTIVE	2026-03-18	300	\N	\N	\N	\N	2	t	f	f	t	2026-03-18 00:48:21.433411	2026-03-18 00:48:21.433411	CLEAN	\N	VIDEO	\N	70	\N
31	7	LAIH	Ollie Dawgz	/uploads/videos/1776260677599-236c9aeae340711d.mp4	60	runnin amok	{dogs,pets}	View Profile	https://gigzito.com/p/gzadmin	Visit Offer	\N	\N	\N	\N	\N	ACTIVE	2026-04-15	300	\N	\N	\N	\N	2	t	f	f	t	2026-04-15 13:45:19.078618	2026-04-15 13:45:19.083	CLEAN	\N	VIDEO	\N	70	\N
\.


--
-- Data for Name: zee_motion_comments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.zee_motion_comments (id, motion_id, author_user_id, author_name, comment_text, created_at) FROM stdin;
\.


--
-- Data for Name: zee_motions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.zee_motions (id, user_id, text, media_url, media_type, created_at) FROM stdin;
1	9	this is a test	\N	\N	2026-03-17 02:06:47.132583
2	9	This is a test again to see the Zmotion feed	\N	\N	2026-03-17 03:34:45.911073
3	13	❤️✨❤️✨	\N	\N	2026-03-18 00:51:01.981837
4	19	Loving life and living it freely	\N	\N	2026-03-22 16:18:36.590925
\.


--
-- Data for Name: zito_tv_events; Type: TABLE DATA; Schema: public; Owner: gigzito
--

COPY public.zito_tv_events (id, title, description, host_name, host_user_id, category, live_url, cta_url, cover_image_url, duration_minutes, start_at, end_at, status, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Name: ad_bookings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gigzito
--

SELECT pg_catalog.setval('public.ad_bookings_id_seq', 1, false);


--
-- Name: ad_inquiries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gigzito
--

SELECT pg_catalog.setval('public.ad_inquiries_id_seq', 8, true);


--
-- Name: all_eyes_slots_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gigzito
--

SELECT pg_catalog.setval('public.all_eyes_slots_id_seq', 1, false);


--
-- Name: audience_broadcasts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gigzito
--

SELECT pg_catalog.setval('public.audience_broadcasts_id_seq', 1, false);


--
-- Name: audit_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gigzito
--

SELECT pg_catalog.setval('public.audit_logs_id_seq', 11, true);


--
-- Name: card_messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gigzito
--

SELECT pg_catalog.setval('public.card_messages_id_seq', 2, true);


--
-- Name: geezee_follows_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.geezee_follows_id_seq', 2, true);


--
-- Name: geo_target_campaigns_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gigzito
--

SELECT pg_catalog.setval('public.geo_target_campaigns_id_seq', 1, false);


--
-- Name: gig_jacks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gigzito
--

SELECT pg_catalog.setval('public.gig_jacks_id_seq', 1, false);


--
-- Name: gigness_card_comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gigzito
--

SELECT pg_catalog.setval('public.gigness_card_comments_id_seq', 1, true);


--
-- Name: gigness_cards_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gigzito
--

SELECT pg_catalog.setval('public.gigness_cards_id_seq', 17, true);


--
-- Name: group_email_invites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gigzito
--

SELECT pg_catalog.setval('public.group_email_invites_id_seq', 1, false);


--
-- Name: group_endeavors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gigzito
--

SELECT pg_catalog.setval('public.group_endeavors_id_seq', 2, true);


--
-- Name: group_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gigzito
--

SELECT pg_catalog.setval('public.group_events_id_seq', 1, true);


--
-- Name: group_kanban_cards_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gigzito
--

SELECT pg_catalog.setval('public.group_kanban_cards_id_seq', 1, true);


--
-- Name: group_members_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gigzito
--

SELECT pg_catalog.setval('public.group_members_id_seq', 4, true);


--
-- Name: group_wall_comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gigzito
--

SELECT pg_catalog.setval('public.group_wall_comments_id_seq', 1, false);


--
-- Name: group_wall_posts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gigzito
--

SELECT pg_catalog.setval('public.group_wall_posts_id_seq', 1, false);


--
-- Name: group_wallet_contributions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gigzito
--

SELECT pg_catalog.setval('public.group_wallet_contributions_id_seq', 1, false);


--
-- Name: group_wallets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gigzito
--

SELECT pg_catalog.setval('public.group_wallets_id_seq', 1, false);


--
-- Name: groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gigzito
--

SELECT pg_catalog.setval('public.groups_id_seq', 6, true);


--
-- Name: gz_band_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gigzito
--

SELECT pg_catalog.setval('public.gz_band_events_id_seq', 1, false);


--
-- Name: gz_band_followers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gigzito
--

SELECT pg_catalog.setval('public.gz_band_followers_id_seq', 1, false);


--
-- Name: gz_band_members_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gigzito
--

SELECT pg_catalog.setval('public.gz_band_members_id_seq', 1, true);


--
-- Name: gz_band_photos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gigzito
--

SELECT pg_catalog.setval('public.gz_band_photos_id_seq', 1, false);


--
-- Name: gz_band_roster_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gigzito
--

SELECT pg_catalog.setval('public.gz_band_roster_id_seq', 1, false);


--
-- Name: gz_band_tv_shows_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gigzito
--

SELECT pg_catalog.setval('public.gz_band_tv_shows_id_seq', 1, false);


--
-- Name: gz_band_wall_comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gigzito
--

SELECT pg_catalog.setval('public.gz_band_wall_comments_id_seq', 1, false);


--
-- Name: gz_band_wall_post_likes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gigzito
--

SELECT pg_catalog.setval('public.gz_band_wall_post_likes_id_seq', 1, false);


--
-- Name: gz_band_wall_posts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gigzito
--

SELECT pg_catalog.setval('public.gz_band_wall_posts_id_seq', 1, true);


--
-- Name: gz_bands_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gigzito
--

SELECT pg_catalog.setval('public.gz_bands_id_seq', 1, true);


--
-- Name: gz_flash_ads_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gigzito
--

SELECT pg_catalog.setval('public.gz_flash_ads_id_seq', 7, true);


--
-- Name: gz_flash_claims_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gigzito
--

SELECT pg_catalog.setval('public.gz_flash_claims_id_seq', 1, true);


--
-- Name: gz_music_comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gigzito
--

SELECT pg_catalog.setval('public.gz_music_comments_id_seq', 1, false);


--
-- Name: gz_music_likes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gigzito
--

SELECT pg_catalog.setval('public.gz_music_likes_id_seq', 6, true);


--
-- Name: gz_music_ratings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gigzito
--

SELECT pg_catalog.setval('public.gz_music_ratings_id_seq', 14, true);


--
-- Name: gz_music_tracks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gigzito
--

SELECT pg_catalog.setval('public.gz_music_tracks_id_seq', 16, true);


--
-- Name: injected_feeds_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gigzito
--

SELECT pg_catalog.setval('public.injected_feeds_id_seq', 14, true);


--
-- Name: leads_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gigzito
--

SELECT pg_catalog.setval('public.leads_id_seq', 3, true);


--
-- Name: listing_comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gigzito
--

SELECT pg_catalog.setval('public.listing_comments_id_seq', 4, true);


--
-- Name: live_sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gigzito
--

SELECT pg_catalog.setval('public.live_sessions_id_seq', 1, false);


--
-- Name: love_votes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gigzito
--

SELECT pg_catalog.setval('public.love_votes_id_seq', 3, true);


--
-- Name: marketer_audiences_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gigzito
--

SELECT pg_catalog.setval('public.marketer_audiences_id_seq', 3, true);


--
-- Name: mfa_codes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gigzito
--

SELECT pg_catalog.setval('public.mfa_codes_id_seq', 274, true);


--
-- Name: notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gigzito
--

SELECT pg_catalog.setval('public.notifications_id_seq', 1, false);


--
-- Name: presenter_contacts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gigzito
--

SELECT pg_catalog.setval('public.presenter_contacts_id_seq', 1, false);


--
-- Name: profile_wall_posts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gigzito
--

SELECT pg_catalog.setval('public.profile_wall_posts_id_seq', 1, false);


--
-- Name: provider_profiles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gigzito
--

SELECT pg_catalog.setval('public.provider_profiles_id_seq', 27, true);


--
-- Name: sponsor_ads_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gigzito
--

SELECT pg_catalog.setval('public.sponsor_ads_id_seq', 8, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gigzito
--

SELECT pg_catalog.setval('public.users_id_seq', 27, true);


--
-- Name: video_likes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gigzito
--

SELECT pg_catalog.setval('public.video_likes_id_seq', 21, true);


--
-- Name: video_listings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gigzito
--

SELECT pg_catalog.setval('public.video_listings_id_seq', 31, true);


--
-- Name: zee_motion_comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.zee_motion_comments_id_seq', 1, false);


--
-- Name: zee_motions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.zee_motions_id_seq', 4, true);


--
-- Name: zito_tv_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gigzito
--

SELECT pg_catalog.setval('public.zito_tv_events_id_seq', 1, false);


--
-- Name: ad_bookings ad_bookings_pkey; Type: CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.ad_bookings
    ADD CONSTRAINT ad_bookings_pkey PRIMARY KEY (id);


--
-- Name: ad_inquiries ad_inquiries_pkey; Type: CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.ad_inquiries
    ADD CONSTRAINT ad_inquiries_pkey PRIMARY KEY (id);


--
-- Name: all_eyes_slots all_eyes_slots_pkey; Type: CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.all_eyes_slots
    ADD CONSTRAINT all_eyes_slots_pkey PRIMARY KEY (id);


--
-- Name: audience_broadcasts audience_broadcasts_pkey; Type: CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.audience_broadcasts
    ADD CONSTRAINT audience_broadcasts_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: card_messages card_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.card_messages
    ADD CONSTRAINT card_messages_pkey PRIMARY KEY (id);


--
-- Name: geezee_follows geezee_follows_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.geezee_follows
    ADD CONSTRAINT geezee_follows_pkey PRIMARY KEY (id);


--
-- Name: geezee_follows geezee_follows_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.geezee_follows
    ADD CONSTRAINT geezee_follows_unique UNIQUE (follower_id, following_user_id);


--
-- Name: geo_target_campaigns geo_target_campaigns_pkey; Type: CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.geo_target_campaigns
    ADD CONSTRAINT geo_target_campaigns_pkey PRIMARY KEY (id);


--
-- Name: gig_jacks gig_jacks_pkey; Type: CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.gig_jacks
    ADD CONSTRAINT gig_jacks_pkey PRIMARY KEY (id);


--
-- Name: gigness_card_comments gigness_card_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.gigness_card_comments
    ADD CONSTRAINT gigness_card_comments_pkey PRIMARY KEY (id);


--
-- Name: gigness_cards gigness_cards_pkey; Type: CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.gigness_cards
    ADD CONSTRAINT gigness_cards_pkey PRIMARY KEY (id);


--
-- Name: gigness_cards gigness_cards_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.gigness_cards
    ADD CONSTRAINT gigness_cards_user_id_unique UNIQUE (user_id);


--
-- Name: group_email_invites group_email_invites_pkey; Type: CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.group_email_invites
    ADD CONSTRAINT group_email_invites_pkey PRIMARY KEY (id);


--
-- Name: group_email_invites group_email_invites_token_key; Type: CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.group_email_invites
    ADD CONSTRAINT group_email_invites_token_key UNIQUE (token);


--
-- Name: group_endeavors group_endeavors_pkey; Type: CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.group_endeavors
    ADD CONSTRAINT group_endeavors_pkey PRIMARY KEY (id);


--
-- Name: group_events group_events_pkey; Type: CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.group_events
    ADD CONSTRAINT group_events_pkey PRIMARY KEY (id);


--
-- Name: group_kanban_cards group_kanban_cards_pkey; Type: CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.group_kanban_cards
    ADD CONSTRAINT group_kanban_cards_pkey PRIMARY KEY (id);


--
-- Name: group_members group_members_group_id_user_id_key; Type: CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.group_members
    ADD CONSTRAINT group_members_group_id_user_id_key UNIQUE (group_id, user_id);


--
-- Name: group_members group_members_pkey; Type: CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.group_members
    ADD CONSTRAINT group_members_pkey PRIMARY KEY (id);


--
-- Name: group_wall_comments group_wall_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.group_wall_comments
    ADD CONSTRAINT group_wall_comments_pkey PRIMARY KEY (id);


--
-- Name: group_wall_posts group_wall_posts_pkey; Type: CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.group_wall_posts
    ADD CONSTRAINT group_wall_posts_pkey PRIMARY KEY (id);


--
-- Name: group_wallet_contributions group_wallet_contributions_pkey; Type: CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.group_wallet_contributions
    ADD CONSTRAINT group_wallet_contributions_pkey PRIMARY KEY (id);


--
-- Name: group_wallets group_wallets_pkey; Type: CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.group_wallets
    ADD CONSTRAINT group_wallets_pkey PRIMARY KEY (id);


--
-- Name: groups groups_invite_code_key; Type: CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT groups_invite_code_key UNIQUE (invite_code);


--
-- Name: groups groups_pkey; Type: CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT groups_pkey PRIMARY KEY (id);


--
-- Name: gz_band_events gz_band_events_pkey; Type: CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.gz_band_events
    ADD CONSTRAINT gz_band_events_pkey PRIMARY KEY (id);


--
-- Name: gz_band_followers gz_band_followers_band_id_email_key; Type: CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.gz_band_followers
    ADD CONSTRAINT gz_band_followers_band_id_email_key UNIQUE (band_id, email);


--
-- Name: gz_band_followers gz_band_followers_pkey; Type: CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.gz_band_followers
    ADD CONSTRAINT gz_band_followers_pkey PRIMARY KEY (id);


--
-- Name: gz_band_members gz_band_members_band_id_user_id_key; Type: CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.gz_band_members
    ADD CONSTRAINT gz_band_members_band_id_user_id_key UNIQUE (band_id, user_id);


--
-- Name: gz_band_members gz_band_members_pkey; Type: CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.gz_band_members
    ADD CONSTRAINT gz_band_members_pkey PRIMARY KEY (id);


--
-- Name: gz_band_photos gz_band_photos_pkey; Type: CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.gz_band_photos
    ADD CONSTRAINT gz_band_photos_pkey PRIMARY KEY (id);


--
-- Name: gz_band_roster gz_band_roster_pkey; Type: CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.gz_band_roster
    ADD CONSTRAINT gz_band_roster_pkey PRIMARY KEY (id);


--
-- Name: gz_band_tv_shows gz_band_tv_shows_pkey; Type: CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.gz_band_tv_shows
    ADD CONSTRAINT gz_band_tv_shows_pkey PRIMARY KEY (id);


--
-- Name: gz_band_wall_comments gz_band_wall_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.gz_band_wall_comments
    ADD CONSTRAINT gz_band_wall_comments_pkey PRIMARY KEY (id);


--
-- Name: gz_band_wall_post_likes gz_band_wall_post_likes_pkey; Type: CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.gz_band_wall_post_likes
    ADD CONSTRAINT gz_band_wall_post_likes_pkey PRIMARY KEY (id);


--
-- Name: gz_band_wall_post_likes gz_band_wall_post_likes_post_id_user_id_key; Type: CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.gz_band_wall_post_likes
    ADD CONSTRAINT gz_band_wall_post_likes_post_id_user_id_key UNIQUE (post_id, user_id);


--
-- Name: gz_band_wall_posts gz_band_wall_posts_pkey; Type: CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.gz_band_wall_posts
    ADD CONSTRAINT gz_band_wall_posts_pkey PRIMARY KEY (id);


--
-- Name: gz_bands gz_bands_pkey; Type: CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.gz_bands
    ADD CONSTRAINT gz_bands_pkey PRIMARY KEY (id);


--
-- Name: gz_bands gz_bands_slug_key; Type: CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.gz_bands
    ADD CONSTRAINT gz_bands_slug_key UNIQUE (slug);


--
-- Name: gz_flash_ads gz_flash_ads_pkey; Type: CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.gz_flash_ads
    ADD CONSTRAINT gz_flash_ads_pkey PRIMARY KEY (id);


--
-- Name: gz_flash_claims gz_flash_claims_pkey; Type: CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.gz_flash_claims
    ADD CONSTRAINT gz_flash_claims_pkey PRIMARY KEY (id);


--
-- Name: gz_music_comments gz_music_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.gz_music_comments
    ADD CONSTRAINT gz_music_comments_pkey PRIMARY KEY (id);


--
-- Name: gz_music_likes gz_music_likes_pkey; Type: CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.gz_music_likes
    ADD CONSTRAINT gz_music_likes_pkey PRIMARY KEY (id);


--
-- Name: gz_music_likes gz_music_likes_track_id_user_id_key; Type: CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.gz_music_likes
    ADD CONSTRAINT gz_music_likes_track_id_user_id_key UNIQUE (track_id, user_id);


--
-- Name: gz_music_ratings gz_music_ratings_pkey; Type: CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.gz_music_ratings
    ADD CONSTRAINT gz_music_ratings_pkey PRIMARY KEY (id);


--
-- Name: gz_music_ratings gz_music_ratings_track_id_user_id_key; Type: CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.gz_music_ratings
    ADD CONSTRAINT gz_music_ratings_track_id_user_id_key UNIQUE (track_id, user_id);


--
-- Name: gz_music_tracks gz_music_tracks_pkey; Type: CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.gz_music_tracks
    ADD CONSTRAINT gz_music_tracks_pkey PRIMARY KEY (id);


--
-- Name: injected_feeds injected_feeds_pkey; Type: CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.injected_feeds
    ADD CONSTRAINT injected_feeds_pkey PRIMARY KEY (id);


--
-- Name: leads leads_pkey; Type: CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.leads
    ADD CONSTRAINT leads_pkey PRIMARY KEY (id);


--
-- Name: listing_comments listing_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.listing_comments
    ADD CONSTRAINT listing_comments_pkey PRIMARY KEY (id);


--
-- Name: live_sessions live_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.live_sessions
    ADD CONSTRAINT live_sessions_pkey PRIMARY KEY (id);


--
-- Name: love_votes love_votes_pkey; Type: CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.love_votes
    ADD CONSTRAINT love_votes_pkey PRIMARY KEY (id);


--
-- Name: love_votes love_votes_voter_user_id_month_key_unique; Type: CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.love_votes
    ADD CONSTRAINT love_votes_voter_user_id_month_key_unique UNIQUE (voter_user_id, month_key);


--
-- Name: marketer_audiences marketer_audiences_pkey; Type: CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.marketer_audiences
    ADD CONSTRAINT marketer_audiences_pkey PRIMARY KEY (id);


--
-- Name: marketer_audiences marketer_audiences_provider_email_unique; Type: CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.marketer_audiences
    ADD CONSTRAINT marketer_audiences_provider_email_unique UNIQUE (provider_user_id, lead_email);


--
-- Name: mfa_codes mfa_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.mfa_codes
    ADD CONSTRAINT mfa_codes_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: presenter_contacts presenter_contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.presenter_contacts
    ADD CONSTRAINT presenter_contacts_pkey PRIMARY KEY (id);


--
-- Name: presenter_contacts presenter_contacts_presenter_user_id_member_user_id_key; Type: CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.presenter_contacts
    ADD CONSTRAINT presenter_contacts_presenter_user_id_member_user_id_key UNIQUE (presenter_user_id, member_user_id);


--
-- Name: profile_wall_posts profile_wall_posts_pkey; Type: CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.profile_wall_posts
    ADD CONSTRAINT profile_wall_posts_pkey PRIMARY KEY (id);


--
-- Name: provider_profiles provider_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.provider_profiles
    ADD CONSTRAINT provider_profiles_pkey PRIMARY KEY (id);


--
-- Name: provider_profiles provider_profiles_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.provider_profiles
    ADD CONSTRAINT provider_profiles_user_id_unique UNIQUE (user_id);


--
-- Name: session session_pkey; Type: CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.session
    ADD CONSTRAINT session_pkey PRIMARY KEY (sid);


--
-- Name: sponsor_ads sponsor_ads_pkey; Type: CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.sponsor_ads
    ADD CONSTRAINT sponsor_ads_pkey PRIMARY KEY (id);


--
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: video_likes video_likes_pkey; Type: CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.video_likes
    ADD CONSTRAINT video_likes_pkey PRIMARY KEY (id);


--
-- Name: video_likes video_likes_video_id_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.video_likes
    ADD CONSTRAINT video_likes_video_id_user_id_unique UNIQUE (video_id, user_id);


--
-- Name: video_listings video_listings_pkey; Type: CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.video_listings
    ADD CONSTRAINT video_listings_pkey PRIMARY KEY (id);


--
-- Name: zee_motion_comments zee_motion_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.zee_motion_comments
    ADD CONSTRAINT zee_motion_comments_pkey PRIMARY KEY (id);


--
-- Name: zee_motions zee_motions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.zee_motions
    ADD CONSTRAINT zee_motions_pkey PRIMARY KEY (id);


--
-- Name: zito_tv_events zito_tv_events_pkey; Type: CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.zito_tv_events
    ADD CONSTRAINT zito_tv_events_pkey PRIMARY KEY (id);


--
-- Name: IDX_session_expire; Type: INDEX; Schema: public; Owner: gigzito
--

CREATE INDEX "IDX_session_expire" ON public.session USING btree (expire);


--
-- Name: gz_band_roster_band_id_idx; Type: INDEX; Schema: public; Owner: gigzito
--

CREATE INDEX gz_band_roster_band_id_idx ON public.gz_band_roster USING btree (band_id);


--
-- Name: idx_listing_comments_listing_id; Type: INDEX; Schema: public; Owner: gigzito
--

CREATE INDEX idx_listing_comments_listing_id ON public.listing_comments USING btree (listing_id);


--
-- Name: ad_bookings ad_bookings_sponsor_ad_id_sponsor_ads_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.ad_bookings
    ADD CONSTRAINT ad_bookings_sponsor_ad_id_sponsor_ads_id_fk FOREIGN KEY (sponsor_ad_id) REFERENCES public.sponsor_ads(id) ON DELETE CASCADE;


--
-- Name: ad_inquiries ad_inquiries_ad_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.ad_inquiries
    ADD CONSTRAINT ad_inquiries_ad_id_fkey FOREIGN KEY (ad_id) REFERENCES public.sponsor_ads(id) ON DELETE CASCADE;


--
-- Name: all_eyes_slots all_eyes_slots_created_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.all_eyes_slots
    ADD CONSTRAINT all_eyes_slots_created_by_users_id_fk FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: all_eyes_slots all_eyes_slots_provider_id_provider_profiles_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.all_eyes_slots
    ADD CONSTRAINT all_eyes_slots_provider_id_provider_profiles_id_fk FOREIGN KEY (provider_id) REFERENCES public.provider_profiles(id) ON DELETE CASCADE;


--
-- Name: all_eyes_slots all_eyes_slots_video_listing_id_video_listings_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.all_eyes_slots
    ADD CONSTRAINT all_eyes_slots_video_listing_id_video_listings_id_fk FOREIGN KEY (video_listing_id) REFERENCES public.video_listings(id) ON DELETE SET NULL;


--
-- Name: audience_broadcasts audience_broadcasts_provider_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.audience_broadcasts
    ADD CONSTRAINT audience_broadcasts_provider_user_id_fkey FOREIGN KEY (provider_user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: audit_logs audit_logs_actor_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_actor_user_id_users_id_fk FOREIGN KEY (actor_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: card_messages card_messages_from_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.card_messages
    ADD CONSTRAINT card_messages_from_user_id_users_id_fk FOREIGN KEY (from_user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: card_messages card_messages_gigness_card_id_gigness_cards_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.card_messages
    ADD CONSTRAINT card_messages_gigness_card_id_gigness_cards_id_fk FOREIGN KEY (gigness_card_id) REFERENCES public.gigness_cards(id) ON DELETE CASCADE;


--
-- Name: card_messages card_messages_to_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.card_messages
    ADD CONSTRAINT card_messages_to_user_id_users_id_fk FOREIGN KEY (to_user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: geezee_follows geezee_follows_follower_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.geezee_follows
    ADD CONSTRAINT geezee_follows_follower_id_fkey FOREIGN KEY (follower_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: geezee_follows geezee_follows_following_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.geezee_follows
    ADD CONSTRAINT geezee_follows_following_user_id_fkey FOREIGN KEY (following_user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: geo_target_campaigns geo_target_campaigns_provider_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.geo_target_campaigns
    ADD CONSTRAINT geo_target_campaigns_provider_user_id_fkey FOREIGN KEY (provider_user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: gig_jacks gig_jacks_provider_id_provider_profiles_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.gig_jacks
    ADD CONSTRAINT gig_jacks_provider_id_provider_profiles_id_fk FOREIGN KEY (provider_id) REFERENCES public.provider_profiles(id) ON DELETE CASCADE;


--
-- Name: gigness_card_comments gigness_card_comments_author_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.gigness_card_comments
    ADD CONSTRAINT gigness_card_comments_author_user_id_fkey FOREIGN KEY (author_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: gigness_card_comments gigness_card_comments_card_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.gigness_card_comments
    ADD CONSTRAINT gigness_card_comments_card_id_fkey FOREIGN KEY (card_id) REFERENCES public.gigness_cards(id) ON DELETE CASCADE;


--
-- Name: gigness_cards gigness_cards_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.gigness_cards
    ADD CONSTRAINT gigness_cards_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: group_email_invites group_email_invites_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.group_email_invites
    ADD CONSTRAINT group_email_invites_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.groups(id) ON DELETE CASCADE;


--
-- Name: group_endeavors group_endeavors_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.group_endeavors
    ADD CONSTRAINT group_endeavors_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.groups(id) ON DELETE CASCADE;


--
-- Name: group_events group_events_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.group_events
    ADD CONSTRAINT group_events_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.groups(id) ON DELETE CASCADE;


--
-- Name: group_kanban_cards group_kanban_cards_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.group_kanban_cards
    ADD CONSTRAINT group_kanban_cards_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.groups(id) ON DELETE CASCADE;


--
-- Name: group_members group_members_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.group_members
    ADD CONSTRAINT group_members_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.groups(id) ON DELETE CASCADE;


--
-- Name: group_wall_comments group_wall_comments_post_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.group_wall_comments
    ADD CONSTRAINT group_wall_comments_post_id_fkey FOREIGN KEY (post_id) REFERENCES public.group_wall_posts(id) ON DELETE CASCADE;


--
-- Name: group_wall_posts group_wall_posts_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.group_wall_posts
    ADD CONSTRAINT group_wall_posts_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.groups(id) ON DELETE CASCADE;


--
-- Name: group_wallet_contributions group_wallet_contributions_wallet_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.group_wallet_contributions
    ADD CONSTRAINT group_wallet_contributions_wallet_id_fkey FOREIGN KEY (wallet_id) REFERENCES public.group_wallets(id) ON DELETE CASCADE;


--
-- Name: group_wallets group_wallets_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.group_wallets
    ADD CONSTRAINT group_wallets_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.groups(id) ON DELETE CASCADE;


--
-- Name: gz_band_events gz_band_events_band_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.gz_band_events
    ADD CONSTRAINT gz_band_events_band_id_fkey FOREIGN KEY (band_id) REFERENCES public.gz_bands(id) ON DELETE CASCADE;


--
-- Name: gz_band_followers gz_band_followers_band_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.gz_band_followers
    ADD CONSTRAINT gz_band_followers_band_id_fkey FOREIGN KEY (band_id) REFERENCES public.gz_bands(id) ON DELETE CASCADE;


--
-- Name: gz_band_followers gz_band_followers_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.gz_band_followers
    ADD CONSTRAINT gz_band_followers_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: gz_band_members gz_band_members_band_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.gz_band_members
    ADD CONSTRAINT gz_band_members_band_id_fkey FOREIGN KEY (band_id) REFERENCES public.gz_bands(id) ON DELETE CASCADE;


--
-- Name: gz_band_photos gz_band_photos_band_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.gz_band_photos
    ADD CONSTRAINT gz_band_photos_band_id_fkey FOREIGN KEY (band_id) REFERENCES public.gz_bands(id) ON DELETE CASCADE;


--
-- Name: gz_band_roster gz_band_roster_band_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.gz_band_roster
    ADD CONSTRAINT gz_band_roster_band_id_fkey FOREIGN KEY (band_id) REFERENCES public.gz_bands(id) ON DELETE CASCADE;


--
-- Name: gz_band_tv_shows gz_band_tv_shows_band_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.gz_band_tv_shows
    ADD CONSTRAINT gz_band_tv_shows_band_id_fkey FOREIGN KEY (band_id) REFERENCES public.gz_bands(id) ON DELETE CASCADE;


--
-- Name: gz_band_wall_comments gz_band_wall_comments_post_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.gz_band_wall_comments
    ADD CONSTRAINT gz_band_wall_comments_post_id_fkey FOREIGN KEY (post_id) REFERENCES public.gz_band_wall_posts(id) ON DELETE CASCADE;


--
-- Name: gz_band_wall_post_likes gz_band_wall_post_likes_post_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.gz_band_wall_post_likes
    ADD CONSTRAINT gz_band_wall_post_likes_post_id_fkey FOREIGN KEY (post_id) REFERENCES public.gz_band_wall_posts(id) ON DELETE CASCADE;


--
-- Name: gz_band_wall_post_likes gz_band_wall_post_likes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.gz_band_wall_post_likes
    ADD CONSTRAINT gz_band_wall_post_likes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: gz_band_wall_posts gz_band_wall_posts_band_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.gz_band_wall_posts
    ADD CONSTRAINT gz_band_wall_posts_band_id_fkey FOREIGN KEY (band_id) REFERENCES public.gz_bands(id) ON DELETE CASCADE;


--
-- Name: gz_flash_ads gz_flash_ads_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.gz_flash_ads
    ADD CONSTRAINT gz_flash_ads_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: gz_flash_claims gz_flash_claims_flash_ad_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.gz_flash_claims
    ADD CONSTRAINT gz_flash_claims_flash_ad_id_fkey FOREIGN KEY (flash_ad_id) REFERENCES public.gz_flash_ads(id) ON DELETE CASCADE;


--
-- Name: gz_music_comments gz_music_comments_track_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.gz_music_comments
    ADD CONSTRAINT gz_music_comments_track_id_fkey FOREIGN KEY (track_id) REFERENCES public.gz_music_tracks(id) ON DELETE CASCADE;


--
-- Name: gz_music_comments gz_music_comments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.gz_music_comments
    ADD CONSTRAINT gz_music_comments_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: gz_music_likes gz_music_likes_track_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.gz_music_likes
    ADD CONSTRAINT gz_music_likes_track_id_fkey FOREIGN KEY (track_id) REFERENCES public.gz_music_tracks(id) ON DELETE CASCADE;


--
-- Name: gz_music_likes gz_music_likes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.gz_music_likes
    ADD CONSTRAINT gz_music_likes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: gz_music_ratings gz_music_ratings_track_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.gz_music_ratings
    ADD CONSTRAINT gz_music_ratings_track_id_fkey FOREIGN KEY (track_id) REFERENCES public.gz_music_tracks(id) ON DELETE CASCADE;


--
-- Name: gz_music_ratings gz_music_ratings_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.gz_music_ratings
    ADD CONSTRAINT gz_music_ratings_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: gz_music_tracks gz_music_tracks_submitted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.gz_music_tracks
    ADD CONSTRAINT gz_music_tracks_submitted_by_fkey FOREIGN KEY (submitted_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: gz_music_tracks gz_music_tracks_uploader_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.gz_music_tracks
    ADD CONSTRAINT gz_music_tracks_uploader_user_id_fkey FOREIGN KEY (uploader_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: injected_feeds injected_feeds_created_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.injected_feeds
    ADD CONSTRAINT injected_feeds_created_by_users_id_fk FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: leads leads_video_id_video_listings_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.leads
    ADD CONSTRAINT leads_video_id_video_listings_id_fk FOREIGN KEY (video_id) REFERENCES public.video_listings(id) ON DELETE CASCADE;


--
-- Name: listing_comments listing_comments_author_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.listing_comments
    ADD CONSTRAINT listing_comments_author_user_id_fkey FOREIGN KEY (author_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: listing_comments listing_comments_listing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.listing_comments
    ADD CONSTRAINT listing_comments_listing_id_fkey FOREIGN KEY (listing_id) REFERENCES public.video_listings(id) ON DELETE CASCADE;


--
-- Name: live_sessions live_sessions_provider_id_provider_profiles_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.live_sessions
    ADD CONSTRAINT live_sessions_provider_id_provider_profiles_id_fk FOREIGN KEY (provider_id) REFERENCES public.provider_profiles(id) ON DELETE CASCADE;


--
-- Name: love_votes love_votes_provider_id_provider_profiles_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.love_votes
    ADD CONSTRAINT love_votes_provider_id_provider_profiles_id_fk FOREIGN KEY (provider_id) REFERENCES public.provider_profiles(id) ON DELETE CASCADE;


--
-- Name: love_votes love_votes_voter_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.love_votes
    ADD CONSTRAINT love_votes_voter_user_id_users_id_fk FOREIGN KEY (voter_user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: marketer_audiences marketer_audiences_source_listing_id_video_listings_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.marketer_audiences
    ADD CONSTRAINT marketer_audiences_source_listing_id_video_listings_id_fk FOREIGN KEY (source_listing_id) REFERENCES public.video_listings(id) ON DELETE SET NULL;


--
-- Name: mfa_codes mfa_codes_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.mfa_codes
    ADD CONSTRAINT mfa_codes_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: presenter_contacts presenter_contacts_member_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.presenter_contacts
    ADD CONSTRAINT presenter_contacts_member_user_id_fkey FOREIGN KEY (member_user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: presenter_contacts presenter_contacts_presenter_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.presenter_contacts
    ADD CONSTRAINT presenter_contacts_presenter_user_id_fkey FOREIGN KEY (presenter_user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: profile_wall_posts profile_wall_posts_author_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.profile_wall_posts
    ADD CONSTRAINT profile_wall_posts_author_user_id_fkey FOREIGN KEY (author_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: profile_wall_posts profile_wall_posts_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.profile_wall_posts
    ADD CONSTRAINT profile_wall_posts_profile_id_fkey FOREIGN KEY (profile_id) REFERENCES public.provider_profiles(id) ON DELETE CASCADE;


--
-- Name: provider_profiles provider_profiles_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.provider_profiles
    ADD CONSTRAINT provider_profiles_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: sponsor_ads sponsor_ads_created_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.sponsor_ads
    ADD CONSTRAINT sponsor_ads_created_by_users_id_fk FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: video_likes video_likes_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.video_likes
    ADD CONSTRAINT video_likes_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: video_likes video_likes_video_id_video_listings_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.video_likes
    ADD CONSTRAINT video_likes_video_id_video_listings_id_fk FOREIGN KEY (video_id) REFERENCES public.video_listings(id) ON DELETE CASCADE;


--
-- Name: video_listings video_listings_bg_music_track_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.video_listings
    ADD CONSTRAINT video_listings_bg_music_track_id_fkey FOREIGN KEY (bg_music_track_id) REFERENCES public.gz_music_tracks(id) ON DELETE SET NULL;


--
-- Name: video_listings video_listings_provider_id_provider_profiles_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.video_listings
    ADD CONSTRAINT video_listings_provider_id_provider_profiles_id_fk FOREIGN KEY (provider_id) REFERENCES public.provider_profiles(id) ON DELETE CASCADE;


--
-- Name: video_listings video_listings_triaged_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.video_listings
    ADD CONSTRAINT video_listings_triaged_by_users_id_fk FOREIGN KEY (triaged_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: zee_motion_comments zee_motion_comments_author_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.zee_motion_comments
    ADD CONSTRAINT zee_motion_comments_author_user_id_fkey FOREIGN KEY (author_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: zee_motion_comments zee_motion_comments_motion_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.zee_motion_comments
    ADD CONSTRAINT zee_motion_comments_motion_id_fkey FOREIGN KEY (motion_id) REFERENCES public.zee_motions(id) ON DELETE CASCADE;


--
-- Name: zee_motions zee_motions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.zee_motions
    ADD CONSTRAINT zee_motions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: zito_tv_events zito_tv_events_created_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.zito_tv_events
    ADD CONSTRAINT zito_tv_events_created_by_users_id_fk FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: zito_tv_events zito_tv_events_host_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: gigzito
--

ALTER TABLE ONLY public.zito_tv_events
    ADD CONSTRAINT zito_tv_events_host_user_id_users_id_fk FOREIGN KEY (host_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

GRANT ALL ON SCHEMA public TO gigzito;


--
-- Name: TABLE geezee_follows; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.geezee_follows TO gigzito;


--
-- Name: SEQUENCE geezee_follows_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.geezee_follows_id_seq TO gigzito;


--
-- Name: TABLE zee_motion_comments; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.zee_motion_comments TO gigzito;


--
-- Name: SEQUENCE zee_motion_comments_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.zee_motion_comments_id_seq TO gigzito;


--
-- Name: TABLE zee_motions; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.zee_motions TO gigzito;


--
-- Name: SEQUENCE zee_motions_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.zee_motions_id_seq TO gigzito;


--
-- PostgreSQL database dump complete
--

\unrestrict FuzmbaSDPAFo4IbjBRd58wVY9yu5K9NIxAbVzNXmprwPN8xXLhjbIcSPJ6UBvE9

